/**
 * Builds Sierpinksi Triangle graphics Frame
 *
 * @author Marisa Loraas
 * @version HW 7, #3
 * @bugs None
 */
package oop.mloraas.hw7.three;

import javax.swing.*;

public class SierpinskiFrame extends JFrame {
    /**
     * default constructor for Sierpinski frame
     */
    public SierpinskiFrame(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(new Sierpinski());
        this.pack();
        this.setVisible(true);
    }

    public static void main(String[] args){
        SierpinskiFrame frame = new SierpinskiFrame();
    }
}
