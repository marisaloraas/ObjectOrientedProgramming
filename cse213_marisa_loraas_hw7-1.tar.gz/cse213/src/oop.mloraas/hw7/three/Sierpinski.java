/**
 * Builds Sierpinski Triangle fractal pattern
 *
 * @author Marisa Loraas
 * @version HW 7, #3
 * @bugs None
 */
package oop.mloraas.hw7.three;
import oop.mloraas.hw5.one.Point;
import javax.swing.*;
import java.awt.*;
import java.util.Random;
import static oop.mloraas.hw7.one.DrawShape.drawPoint;

public class Sierpinski extends JPanel {
    /**
     * Default Sierpinski triangle constructor
     */
    public Sierpinski(){
        setPreferredSize(new Dimension(500, 500));
        setBackground(Color.BLACK);
    }

    /**
     * Makes the specific color of the triangle
     * @param x a point drawn
     * @param R Coordinates of the color red
     * @param G coordinates of the color green
     * @param B coordinates of the color blue
     * @return new color of x
     */
    public Color triangleColor(Point x, Point R, Point G, Point B) {
        int r,b,g;
        int L = 400;
        r = (int)(255 * (L - x.distance(R))/ L);
        g = (int)(255 * (L - x.distance(G))/ L);
        b = (int)(255 * (L - x.distance(B))/ L);

        if(r < 0)
            r = 0;
        if(r > 255)
            r = 255;

        if(g < 0)
            g = 0;
        if(g > 255)
            g = 255;

        if(b < 0)
            b = 0;
        if(b > 255)
            b = 255;

        return new Color(r, g, b);
    }

    /**
     * Builds the sierpinski triangle pattern
     * @param graphics graphics
     */
    @Override
    public void paintComponent(Graphics graphics){
        super.paintComponent(graphics);
        Point R = new Point(250, 77);
        Point G = new Point(50, 423);
        Point B = new Point(450, 423);
        Point[] array = new Point[]{R, B, G};
        Point x = new Point(R);
        Point target = new Point();
        for(int i = 0; i <= 50000; i++){
            target = array[new Random().nextInt(3)];
            x  = new Point((target.getX() + x.getX())/2, (target.getY() + x.getY())/2);
            drawPoint((Graphics2D) graphics, x, triangleColor(x, R, G, B));
        }

    }

}
