/**
 * Builds a go board
 *
 * @author Marisa Loraas
 * @version HW 7, #4
 * @bugs None
 */

package oop.mloraas.hw7.four;
import oop.mloraas.hw5.one.Circle;
import oop.mloraas.hw7.one.DrawShape;
import oop.mloraas.hw5.one.Rectangle;
import oop.mloraas.hw5.one.Point;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

public class GoBoard extends JComponent {
    private Color[][] stones;

    /**
     * default constructor to build the go board
     */
    public GoBoard(){
        setPreferredSize(new Dimension(720, 720));
        this.stones = new Color[19][19];
        for(int i = 0; i < 19; i++)
            for(int j = 0; j < 19; j++)
                this.stones[i][j] = null;
    }

    /**
     * will build a goboard object given a filepath (that is in a specific format)
     * @param file file path
     * @return new go board
     */
    public static GoBoard fromFile(String file){
        GoBoard goBoard = new GoBoard();
        try {
            Scanner in = new Scanner(new FileInputStream(file));
            String[] column = {"A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L",
            "M", "N", "O", "P", "Q", "R", "S", "T"};
            int j;
            while(in.hasNext()){
                String line = in.nextLine();
                String[] split = line.split(" ");
                for(int i = 0; i < 19; i++){
                    if(column[i].equals(split[1])){
                        j = Integer.parseInt(split[2]) - 1;
                        if(split[0].equals("B"))
                            goBoard.stones[i][j] = Color.BLACK;
                        else if(split[0].equals("W"))
                            goBoard.stones[i][j] = Color.WHITE;
                    }
                }
            }
            in.close();
        }catch (Exception e){
            System.out.println("File Path not found");
        }
        return goBoard;
    }

    /**
     * adds a stone to the go board
     * @param column column number
     * @param row row number
     * @param color color of stone
     */
    public void addStone(int column, int row, Color color){
        if(column < 0 || column > 18)
            return;
        else if(row < 0 || row > 18)
            return;
        else
            this.stones[column][row] = color;
    }

    /**
     * Builds the go board graphic
     * @param graphics graphics
     */
    public void paintComponent(Graphics graphics){
        BufferedImage bufferedImage = null;
        try{
            bufferedImage = ImageIO.read(new File("bamboo.jpg"));
        }catch(Exception e){
            System.out.println("Background Image not found");
        }

        Graphics2D graphics2D = (Graphics2D) graphics;
        if(bufferedImage != null)
            graphics2D.drawImage(bufferedImage, 0, 0, null);

        Rectangle board = new Rectangle(35, 35);
        for(int i = 0; i < 18; i++){
            for(int j = 0; j < 18; j++){
                board.setPosition(45 + i * 35, 45 + j * 35);
                DrawShape.drawRectangle(graphics2D, board, Color.BLACK);
            }
        }

        Circle stone = new Circle(new Point(0,0), 16);
        for(int i = 0; i <= 18; i++){
            for(int j = 0; j <= 18; j++){
                if(this.stones[i][j] != null) {
                    stone.setCenter(new Point(45 + i * 35, 45 + j * 35));
                    DrawShape.drawCircle(graphics2D, stone, this.stones[i][j]);
                }
            }
        }
    }

}
