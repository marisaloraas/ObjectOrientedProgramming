/**
 * Builds the go board frame
 *
 * @author Marisa Loraas
 * @version HW 7, #4
 * @bugs None
 */
package oop.mloraas.hw7.four;

import javax.swing.*;
import java.awt.*;

public class GoFrame extends JFrame {

    /**
     * Builds the go frame given a go board
     * @param goBoard go board
     */
    public GoFrame(GoBoard goBoard){
        JPanel panel = new JPanel();
        panel.setBackground(Color.decode("#ffd294"));

        JLabel black = new JLabel("Black: 23", SwingConstants.CENTER);
        JLabel white = new JLabel("White: 12.5", SwingConstants.CENTER);
        black.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 32));
        black.setForeground(Color.BLACK);
        white.setForeground(Color.WHITE);
        white.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 32));
        panel.setLayout(new GridLayout(1,2));
        panel.add(black);
        panel.add(white);
        this.add(goBoard);
        this.add(panel, BorderLayout.SOUTH);
        this.pack();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args){
        GoFrame goFrame = new GoFrame(GoBoard.fromFile("stones.txt"));
    }
}
