/**
 *Builds analog clock face
 *
 * @author Marisa Loraas
 * @version HW 7, #2
 * @bugs None
 */
package oop.mloraas.hw7.two;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

import java.time.LocalTime;

public class ClockFace extends JComponent {
    private int hour;
    private int minute;
    private int second;

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public int getSecond() {
        return second;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public void setSecond(int second){
        this.second = second;
    }

    /**
     * default constructor for clock face to set to the current local time
     */
    public ClockFace(){
        setPreferredSize(new Dimension(400, 400));
        this.hour = LocalTime.now().getHour();
        this.minute = LocalTime.now().getMinute();
        this.second = LocalTime.now().getSecond();
    }

    /**
     * Clock face constructor given input
     * @param hour hour for time
     * @param minute minute for time
     * @param second second for time
     */
    public ClockFace(int hour, int minute, int second){
        setPreferredSize(new Dimension(400, 400));
        if(hour >= 0 && hour <=23)
            this.hour = hour;
        else
            this.hour = LocalTime.now().getHour();

        if(minute >= 0 && minute <=59)
            this.minute = minute;
        else
            this.minute = LocalTime.now().getMinute();

        if(second >= 0 && second <=59)
            this.second = second;
        else
            this.second = LocalTime.now().getSecond();
    }

    /**
     * Builds the analog clock graphic
     * @param graphics graphics
     */
    public void paintComponent(Graphics graphics){
        Graphics2D graphics2D = (Graphics2D) graphics;
        try {
            BufferedImage bg = ImageIO.read(new File("clock.jpg"));
            graphics2D.drawImage(bg, 0, 0, null);

            Color tmp = graphics2D.getColor();

            graphics2D.setStroke(new BasicStroke(2)); //second
            graphics2D.setColor(Color.RED);
            double angle_sec = ((Math.PI / 30) * this.second);
            int x_sec = (int)(200 + 190 * Math.sin(angle_sec));
            int y_sec = (int)(200 - 190 * Math.cos(angle_sec));
            graphics2D.drawLine(200, 200, x_sec, y_sec);

            graphics2D.setStroke(new BasicStroke(4)); //minute
            graphics.setColor(tmp);
            double angle_min = (Math.PI / 30) * this.minute;
            int x_min = (int)(200 + 160 * Math.sin(angle_min));
            int y_min = (int)(200 - 160 * Math.cos(angle_min));
            graphics2D.drawLine(200, 200, x_min, y_min);

            graphics2D.setStroke(new BasicStroke(6)); //hr
            double angle_hr = (Math.PI / 6) * (this.hour % 12) + (Math.PI/360) * this.minute;
            int x_hr = (int)(200 + 100 * Math.sin(angle_hr));
            int y_hr = (int)(200 - 100 * Math.cos(angle_hr));
            graphics2D.drawLine(200, 200, x_hr, y_hr);

        }catch (Exception e){
            System.out.println("File not found");
        }
    }
}
