/**
 *Builds analog clock Frame
 *
 * @author Marisa Loraas
 * @version HW 7, #2
 * @bugs None
 */

package oop.mloraas.hw7.two;

import javax.swing.*;
import java.awt.*;
import java.util.TimeZone;

public class ClockFrame extends JFrame {
    /**
     * Default constructor for analog clock frame with labels
     */
    public ClockFrame(){
        ClockFace face = new ClockFace();
        JLabel label = new JLabel(TimeZone.getDefault().getDisplayName(), SwingConstants.CENTER);
        label.setFont(new Font(Font.SANS_SERIF, Font.BOLD , 24));
        add(label, BorderLayout.NORTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(face);
        this.pack();
        this.setVisible(true);

    }

    public static void main(String[] args){
        ClockFrame cf = new ClockFrame();
    }
}
