/**
 * Shape area comparator
 *
 * @author Marisa Loraas
 * @version HW 5, #1
 * @bugs None
 */
package oop.mloraas.hw5.one;

import java.util.Comparator;

public class ShapeAreaComparator implements Comparator<Shape> {
    public int compare(Shape shapeA, Shape shapeB) {
        return shapeA.area() > shapeB.area() ? 1:
                shapeA.area() < shapeB.area() ? -1 :
                        0;
    }
}
