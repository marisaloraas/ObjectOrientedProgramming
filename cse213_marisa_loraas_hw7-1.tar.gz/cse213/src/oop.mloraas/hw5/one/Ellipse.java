/**
 * Parallelogram function from hw3
 *
 * @author Marisa Loraas
 * @version HW 5, #1
 * @bugs None
 */

package oop.mloraas.hw5.one;

public class Ellipse extends Circle {
    private double minorRadius;

    public double getMinorRadius() {
        return minorRadius;
    }

    public void setMinorRadius(double minorRadius) {
        this.minorRadius = minorRadius;
    }

    /**
     * Default setter for ellipse
     */
    public Ellipse(){
        super();
        this.minorRadius = this.getRadius();
    }

    /**
     * Sets ellipse for all parameters
     * @param center center point of ellipse
     * @param radius major radius of ellipse
     * @param minorRadius minor radius of ellipse
     */
    public Ellipse(Point center, double radius, double minorRadius){
        super(center, radius);
        this.minorRadius = minorRadius;
    }

    /**
     * gets width of ellipse
     * @return width
     */
    @Override
    public double width(){
        return  this.getRadius() * 2;
    }

    /**
     * gets height of ellipse
     * @return height
     */
    @Override
    public double height(){
        return this.getMinorRadius() * 2;
    }

    /**
     * gets diameter of ellipse
     * @return diameter
     */
    @Override
    public double diameter(){
        return this.getRadius() * 2;
    }

    /**
     * calculates area of ellipse
     * @return area
     */
    @Override
    public double area(){
        return Math.PI * this.getMinorRadius() * this.getRadius();
    }

    /**
     * calculates perimeter of ellipse
     * @return perimeter
     */
    @Override
    public double perimeter(){
        return Math.sqrt(2*Math.PI) * Math.sqrt(Math.pow( this.getMinorRadius(), 2) +
                Math.pow(this.getRadius(), 2));
    }

    /**
     * Determines if a point is in bounds of a given ellipse
     * @param point to see if in bounds
     * @return True or false if inbounds
     */
    @Override
    public boolean inBounds(Point point){
        double x = Math.pow(point.getX() - this.getCenter().getX(), 2)
                / Math.pow(this.getRadius(), 2);
        double y = Math.pow(point.getY() - this.getCenter().getY(), 2)
                / Math.pow(this.getMinorRadius(), 2);
        return x + y <= 1;
    }

    /**
     * gets bounding box around ellipse
     * @return rectangle (bounding box)
     */
    @Override
    public Rectangle getBoundingBox(){
        Point point1 = new Point(this.getCenter().getX() - this.getRadius(),
                this.getCenter().getY() -this.getMinorRadius());
        Point point2 = new Point(this.getCenter().getX() +this.getRadius(),
                this.getCenter().getY() + this.getMinorRadius());
        return new Rectangle(point1, point2);
    }

    /**
     * calculates the focal point of an ellipse
     * @return focal point
     */
    public double focalDistance() {
        return Math.sqrt(Math.abs(Math.pow(this.getRadius(),2) -
                Math.pow(this.getMinorRadius(), 2)));
    }

    /**
     * calculates eccentricity of an ellipse
     * @return eccentricity
     */
    public double eccentricity(){
        return focalDistance() / Math.max(this.getRadius(), this.minorRadius);
    }
}

