/**
 * Converts a normal mathematic expression into an RPN expression to be solved
 * and solves in main function from user input
 *
 * @author Marisa Loraas
 * @version HW 6, #3
 * @bugs none
 */
package oop.mloraas.hw6.three;

import oop.mloraas.hw6.two.Operator;
import oop.mloraas.hw6.two.RPN;
import oop.mloraas.hw6.two.Token;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Calculator {
    /**
     * converts normal mathmatic expression into an RPN expression
     * @param tokens Arraylist of tokens that represent a normal mathmatic expression
     * @return Arraylist of tokens that represent the same expression in RPN form
     */
    public static ArrayList<Token> toRPN( ArrayList<Token> tokens){
        ArrayList<Token> output = new ArrayList<>();
        Stack<Token> operators = new Stack<>();
        for(int i = 0; i < tokens.size(); i++){
            if(!(tokens.get(i).isOperator()))
                output.add(tokens.get(i));
            else{
                if(tokens.get(i).getOperator() != Operator.LPAREN && tokens.get(i).getOperator() != Operator.RPAREN){

                    while(!operators.isEmpty() &&
                            operators.peek().getOperator() != Operator.RPAREN && operators.peek().getOperator() != Operator.LPAREN &&
                            operators.peek().getOperator().getPrecedence() > tokens.get(i).getOperator().getPrecedence() &&
                            operators.peek().getOperator() != Operator.EXPONENT && tokens.get(i).getOperator() != Operator.EXPONENT){
                        output.add(operators.pop());
                    }
                    operators.push(tokens.get(i));

                }else if(tokens.get(i).getOperator() == Operator.LPAREN)
                    operators.push(tokens.get(i));
                else if(tokens.get(i).getOperator() == Operator.RPAREN && !operators.isEmpty()){

                    while(operators.peek().getOperator() != Operator.LPAREN)
                        output.add(operators.pop());

                    if(operators.isEmpty())
                        throw new ArithmeticException("Error! Invalid Expression!");

                    operators.pop();
                }
            }
        }
               while(!operators.empty())
                   output.add(operators.pop());

            return output;
    }

    public static void main(String[] args) throws IOException {
        String expression;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while(true){
            ArrayList<Token> tokens = new ArrayList<>();
            System.out.println("Expression> ");
            expression = reader.readLine();
            if(expression == null)
                break;
            //There must be spaces between every character including parenthesis to work
            List<String> strings = Arrays.asList(expression.split(" "));
            for (int i = 0; i < strings.size(); i++) {
                tokens.add(Token.parseToken(strings.get(i)));
            }
            try {
                System.out.println(">>> " + RPN.eval(toRPN(tokens)));
            } catch (EmptyStackException e) {
                System.out.println("Invalid Expression");
            } catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
    }
}
