package oop.mloraas.hw6.two;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.ArrayList;
import java.util.spi.AbstractResourceBundleProvider;

import static org.junit.Assert.*;

public class RPNTest {
    private static ArrayList<Token> tokens;

    @BeforeClass
    public static void initialize(){
       tokens = new ArrayList<>();
    }

    @Test
    public void eval_addition() {
        tokens.clear();
        tokens.add(Token.parseToken("3"));
        tokens.add(Token.parseToken("4"));
        tokens.add(Token.parseToken("+"));
        assertEquals("RPN addition dosnt work correctly", 7, RPN.eval(tokens), 0.1);
    }

    @Test
    public void eval_subtraction(){
        tokens.clear();
        tokens.add(Token.parseToken("4"));
        tokens.add(Token.parseToken("3"));
        tokens.add(Token.parseToken("-"));
        assertEquals("RPN subtraction dosnt work correctly", 1, RPN.eval(tokens), 0.1);
    }

    @Test
    public void eval_multiplication(){
        tokens.clear();
        tokens.add(Token.parseToken("4"));
        tokens.add(Token.parseToken("3"));
        tokens.add(Token.parseToken("*"));
        assertEquals("RPN multiplication dosn't work correctly", 12, RPN.eval(tokens), 0.1);
    }

    @Test
    public void eval_division(){
        tokens.clear();
        tokens.add(Token.parseToken("12"));
        tokens.add(Token.parseToken("4"));
        tokens.add(Token.parseToken("/"));
        assertEquals("RPN division dosn't work correctly", 3, RPN.eval(tokens), 0.1);
    }
    @Test (expected = ArithmeticException.class)
    public void eval_exception(){
        tokens.clear();
        tokens.add(Token.parseToken("4"));
        tokens.add(Token.parseToken("3"));
        assertEquals("Expected Exception not thrown", RPN.eval(tokens));

    }

    @AfterClass
    public static void clears(){
        tokens.clear();
        System.out.println("Array List of Tokens has been cleared\nSize of Arraylist : " + tokens.size());
    }
}