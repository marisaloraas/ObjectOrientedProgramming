/**
 * Operator Enumeration Class, includes every operator and how they
 * are evaluated in mathematical expressions
 *
 * @author Marisa Loraas
 * @version HW 6, #2
 * @bugs None
 */
package oop.mloraas.hw6.two;


public enum Operator {
    LPAREN,
    RPAREN,
    EXPONENT,
    MULTIPLY,
    DIVIDE,
    MODULO,
    ADD,
    SUBTRACT;

    /**
     * gets the precedence of a particular operator (PEMDAS)
     * @return precedence number
     */
    public int getPrecedence(){
        if(this == LPAREN || this == RPAREN)
            return 3;
        else if(this == EXPONENT)
            return 2;
        else if(this == MULTIPLY || this == DIVIDE || this == MODULO)
            return 1;
        else if(this == ADD || this == SUBTRACT)
            return 0;
        else
            return -1;
    }

    /**
     * evaluates different math operations
     * @param x first number
     * @param y second number
     * @return operation on the two numbers
     */
    public double eval(double x, double y){
        if(this == EXPONENT)
            return Math.pow(x,y);
        else if(this == MULTIPLY)
            return x * y;
        else if(this == DIVIDE)
            return x / y;
        else if(this == MODULO)
            return x % y;
        else if(this == ADD)
            return x + y;
        else if(this == SUBTRACT)
            return x - y;
        else
            return -1;
    }

    /**
     * converts different operations into string format
     * @return string format of math operations
     */
    public String toString(){
        if(this == LPAREN)
            return "(";
        else if(this == RPAREN)
            return ")";
        else if(this == EXPONENT)
            return "^";
        else if(this == MULTIPLY)
            return "*";
        else if(this == DIVIDE)
            return "/";
        else if(this == MODULO)
            return "%";
        else if(this == ADD)
            return "+";
        else if(this == SUBTRACT)
            return "-";
        else
            return "NOT FOUND";
    }
}
