/**
 * Creates tokens that can either be a number or an operator
 *
 * @author Marisa Loraas
 * @version HW 6, #2
 * @bugs None
 */
package oop.mloraas.hw6.two;

public class Token {
    private Double number;
    private Operator operator;

    public Double getNumber() {
        return this.number;
    }
    public Operator getOperator(){
        return this.operator;
    }

    /**
     * creates a token that is a number
     * @param number tokens value
     */
    public Token(double number){
        this.number = number;
        this.operator = null;
    }

    /**
     * creates a token that is an operator
     * @param operator type of operator of token
     */
    public Token(Operator operator){
        this.operator = operator;
        this.number = null;
    }

    /**
     * determines whether a token is an operator or not
     * @return true if operator
     */
    public boolean isOperator(){
        return this.operator != null;
    }

    /**
     * takes a string input and creates the proper token
     * @param str input
     * @return token value of input
     */
    public static Token parseToken(String str) {
        switch (str) {
            case "(":
                return new Token(Operator.LPAREN);
            case ")":
                return new Token(Operator.RPAREN);
            case "^":
                return new Token(Operator.EXPONENT);
            case "*":
                return new Token(Operator.MULTIPLY);
            case "/":
                return new Token(Operator.DIVIDE);
            case "%":
                return new Token(Operator.MODULO);
            case "+":
                return new Token(Operator.ADD);
            case "-":
                return new Token(Operator.SUBTRACT);
            default:
                return new Token(Double.parseDouble(str));
        }
    }
}
