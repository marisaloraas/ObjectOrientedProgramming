/**
 * RPN calculator with main function that reads in input and evaluates expression
 *
 * @author Marisa Loraas
 * @version HW 6, #2
 * @bugs none
 */
package oop.mloraas.hw6.two;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class RPN {
    /**
     * Evaluates Expression based on token input
     * @param tokens components of expression entered
     * @return evaluated expression
     */
    public static double eval(ArrayList<Token> tokens){
        Stack<Double> stack = new Stack<>();
        double a, b, ans;
        for(int i = 0; i < tokens.size(); i++){
            if(tokens.get(i).isOperator()){
                b = stack.pop();
                a = stack.pop();
                stack.push(tokens.get(i).getOperator().eval(a,b));
            }else
                stack.push(tokens.get(i).getNumber());
        }
        try{
            ans = stack.pop();
        }catch(EmptyStackException e){
            throw new ArithmeticException("Invalid RPN Expression!");
        }

        if(!stack.empty())
            throw new ArithmeticException("Invalid RPN Expression!");
        else
            return ans;

    }

    public static void main(String[] args) throws IOException {
        String expression;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while(true){
            ArrayList<Token> tokens = new ArrayList<>();
            System.out.println("RPN Expression> ");
            expression = reader.readLine();
            if(expression == null)
                break;
            List<String> strings = Arrays.asList(expression.split(" "));
            for (int i = 0; i < strings.size(); i++) {
                tokens.add(Token.parseToken(strings.get(i)));
            }
            try {
                System.out.println(">>> " + eval(tokens));
            } catch (EmptyStackException e) {
                System.out.println("Invalid RPN Expression");
            } catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
    }
}
