/**
 * Builds A binary search tree with functions like add, remove, and prints traversals.
 *
 * @author Marisa Loraas
 * @version HW 6, #1
 * @bugs None
 */

package oop.mloraas.hw6.one;

import java.util.ArrayList;
import java.util.Comparator;

public class BinarySearchTree <E>{
    public enum Traversal{ PREORDER, INORDER, POSTORDER}

    private class Node{
        private E data;
        private Node left;
        private Node right;

        /**
         * Builds node that points to a right and left node on the tree
         * @param data value of the node
         * @param left left node
         * @param right right node
         */
        private Node(E data, Node left, Node right){
            this.data = data;
            this.left = left;
            this.right = right;
        }

        /**
         * Adds a node to the binary tree
         * @param new_data value of new node being added
         * @return new node
         */
        private Node add(E new_data){
            if(comparator.compare(this.data, new_data) < 0){
                if(this.right == null)
                 return this.right = new Node(new_data, null, null);
                else
                    return this.right.add(new_data);
            }else
                if(this.left == null)
                 return this.left = new Node(new_data, null, null);
                else
                    return this.left.add(new_data);
        }

        /**
         * Finds a node in the binary tree
         * @param this_data data that needs to be found
         * @return Node that matches this_data
         */
        private Node find(E this_data){
            if(this.right == null && this.left == null)
                return null;
            if(comparator.compare(this.right.data, this_data) == 0)
                return this.right;
            if(comparator.compare(this.left.data, this_data) == 0)
                return this.left;

            if(comparator.compare(this.data, this_data) < 0)
                return this.right.find(this_data);
            else
                return this.left;
        }

        /**
         * Removes node
         * @param this_data data of node that needs to be removed
         * @return changed node on tree
         */
        private void remove(E this_data){
            if(this.right == null && this.left == null)
                return;
            else if(comparator.compare(this.right.data, this_data) == 0){
                if(this.right.right == null && this.right.left == null)
                    this.right = null;
                else if(this.right.right == null && this.right.left != null)
                    this.right = right.left;
                else if(this.right.right != null && this.right.left == null)
                    this.right = this.right.right;
                else{
                    Node tmp = this.right.find(this.right.left.findMax());
                    remove(this.right.left.findMax());
                    this.right = tmp;
                }
            }else if(comparator.compare(left.data, this_data) == 0){
                if(this.left.right == null && this.left.left == null)
                    this.left = null;
                else if(this.left.right == null && this.left.left != null)
                    this.left = this.left.left;
                else if(this.left.right != null && this.left.left == null)
                    this.left = this.left.right;
                else{
                    Node tmp = this.left.find(this.left.left.findMax());
                    remove(this.left.left.findMax());
                    this.left = tmp;
                }
            }else if(comparator.compare(this.data, this_data) < 0)
                this.right.remove(this_data);
            else
                this.left.remove(this_data);
        }

        /**
         * finds the leftmost node
         * @return leftmost node
         */
        private E findMin(){
            if(this.left == null)
                return this.data;
            else
                return this.left.findMin();
        }

        /**
         * Finds the rightmost node
         * @return rightmost node
         */
        private E findMax(){
            if(this.right == null)
                return this.data;
            else
                return this.right.findMax();
        }
    }

    private Node root;
    private int size;
    private Comparator<E> comparator;

    public int getSize() {
        return size;
    }

    /**
     * Builds binary tree based on a comparator
     * @param comparator comparator function
     */
    public BinarySearchTree(Comparator<E> comparator){
        this.comparator = comparator;
        this.size = 0;
        this.root = null;
    }

    /**
     * adds new node to tree
     * @param new_data new data being added
     */
    public void add(E new_data){
        this.size++;
        if(this.root == null)
            this.root = new Node(new_data, null, null);
        else
            this.root.add(new_data);
    }

    /**
     * removes node from tree
     * @param data data being removed
     */
    public void remove (E data){
        this.size--;
        if(comparator.compare(this.root.data , data) == 0){
            if(this.root.right == null && this.root.left == null)
                this.root = null;
            else if (this.root.right == null && this.root.left != null)
                this.root = this.root.left;
            else if(this.root.right != null && this.root.left == null)
                this.root = this.root.right;
            else{
                Node tmp = this.root.find(this.root.left.findMax());
                remove(this.root.left.findMax());
                this.root = tmp;
            }
        }else
            this.root.remove(data);
    }

    /**
     * find node on tree
     * @param data data that needs to be found
     * @return true or false if node was found
     */
    public boolean find(E data){
        if(comparator.compare(this.root.data, data) == 0){
            return true;
        }else if(this.root.find(data) != null){
            return true;
        }else
            return false;
    }

    /**
     * finds the leftmost node on the tree
     * @return node found
     */
    public E findMin(){
        if(this.root == null)
            return null;
        else if(this.root.left == null)
            return this.root.data;
        else
            return this.root.left.findMin();
    }

    /**
     * finds the rightmost node on the tree
     * @return node found
     */
    public E findMax(){
        if(this.root == null)
            return null;
        else if(this.root.right == null)
            return this.root.data;
        else
            return this.root.right.findMax();
    }

    /**
     * finds if a tree is empty
     * @return true if empty, false if not
     */
    public boolean isEmpty(){
        if(this.root == null)
            return true;
        else
            return false;
    }

    /**
     * removes every node in a tree
     */
    public void clear(){
        this.size = 0;
        this.root = null;
    }

    /**
     * makes an array list of data into a binary tree
     * @param list list of data
     */
    public void addAll(ArrayList<E> list){
        for(int i = 0; i < list.size(); i ++)
            add(list.get(i));
    }

    /**
     * prints out a tree based in a specific traversal
     * @param traversal Preorder, inorder, or postorder
     */
    public void print(Traversal traversal){
        if(traversal == Traversal.PREORDER)
            preorder(this.root);
        else if(traversal == Traversal.INORDER)
            inorder(this.root);
        else if(traversal == Traversal.POSTORDER)
            postorder(this.root);
    }

    /**
     * prints out a tree in preorder
     * @param parent root of tree
     */
    private void preorder(Node parent){
        System.out.println(parent.data);
        if(parent.left != null)
            preorder(parent.left);
        if(parent.right != null)
            preorder(parent.right);
    }

    /**
     * prints out a tree in inorder
     * @param parent root of tree
     */
    private void inorder(Node parent){
        if(parent.left != null)
            inorder(parent.left);
        System.out.println(parent.data);
        if(parent.right != null)
            inorder(parent.right);
    }

    /**
     * prints out tre in postorder
     * @param parent root of tree
     */
    private void postorder(Node parent){
        if(parent.left != null)
            preorder(parent.left);
        if(parent.right != null)
            preorder(parent.right);
        System.out.println(parent.data);
    }
}
