/**
 * Makes binary trees based on titles, authors, and years of books being
 * published from library.txt
 *
 * @author Marisa Loraas
 * @version HW 6, #1
 * @bugs None
 */

package oop.mloraas.hw6.one;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Library {
    public static void main(String[] args){
        FileReader read = null;
        Scanner in = new Scanner(System.in);
        ArrayList<Book> book = new ArrayList<>();
        String line;
        String[] split;
        String publisher;

        try{
            read = new FileReader("library.txt");
        }catch(IOException e){
            System.out.println("Error! Cannot open file: library.txt");
        }

        in = new Scanner(read);
        while(in.hasNextLine()){
            line = in.nextLine();
            split = line.split(", ");
            publisher = in.nextLine();
            Book b = new Book(split[0], split[1], Integer.parseInt(split[2]), publisher);
            book.add(b);
        }

        BinarySearchTree<Book> authors = new BinarySearchTree<>((Book a, Book b) -> {return a.getAuthor()[0].compareTo(b.getAuthor()[0]);});
        BinarySearchTree<Book> titles = new BinarySearchTree<>((Book a, Book b) -> {return a.getTitle().compareTo(b.getTitle());});
        BinarySearchTree<Book> years = new BinarySearchTree<>((Book a, Book b) -> {return a.getYear() - b.getYear();});

       titles.addAll(book);
       years.addAll(book);
       authors.addAll(book);

       System.out.println("Sorted by titles, printed in PreOrder");
       titles.print(BinarySearchTree.Traversal.PREORDER);
       System.out.println("\n \n Sorted by Years in InOrder");
        years.print(BinarySearchTree.Traversal.INORDER);
        System.out.println("\n \n Sorted by authors in PostOrder");
        authors.print(BinarySearchTree.Traversal.POSTORDER);
        System.out.println("\n \n Most recently published book: \n " + years.findMax());


        authors.remove(authors.findMin());

        Book test2 = new Book ("Miguel de Cervantes", "Some Title", 0, "Some Publisher");
        System.out.print("Contains Book With Miguel de Cervantes: " );
        if(authors.find(test2))
            System.out.print("Yes");
        else
            System.out.print("No");
        System.out.println();

        Book test3 = new Book ("William Shakespeare", "Some Title", 0, "Some Publisher");
        System.out.print("Contains Book with William Shakespeare:  ");
        if(authors.find(test3))
            System.out.print("Yes");
        else
            System.out.print("No");
    }

}
