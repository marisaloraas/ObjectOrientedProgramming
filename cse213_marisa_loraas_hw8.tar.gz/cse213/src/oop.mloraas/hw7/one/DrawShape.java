/**
 * Draws three different shapes using Graphics2D, a point, a rectangle, and a circle
 *
 * @author Marisa Loraas
 * @version HW 7, #1
 * @bugs None
 */

package oop.mloraas.hw7.one;

import java.awt.*;

import oop.mloraas.hw5.one.Circle;
import oop.mloraas.hw5.one.Point;
import oop.mloraas.hw5.one.Rectangle;

public class DrawShape {

    /**
     * Draws a single Point
     * @param graphics graphics
     * @param p a Point object from hw5
     * @param color color of point
     */
    public static void drawPoint(Graphics2D graphics, Point p, Color color){
        Color tmp = graphics.getColor();
        graphics.setColor(color);
        graphics.drawOval((int) p.getX(), (int) p.getY(), 1, 1);
        graphics.setColor(tmp);
    }

    /**
     * Draws a rectangle
     * @param graphics graphics
     * @param r rectangle object from hw5
     * @param color color of rectangle
     */
    public static void drawRectangle(Graphics2D graphics, Rectangle r, Color color){
        Color tmp = graphics.getColor();
        graphics.setColor(color);
        graphics.drawRect((int) r.getLowerLeft().getX(), (int) r.getLowerLeft().getY(),
                (int) r.width(), (int) r.height());
        graphics.setColor(tmp);
    }

    /**
     * Draws a circle
     * @param graphics graphics
     * @param c Circle object from hw5
     * @param color color of circle
     */
    public static void drawCircle(Graphics2D graphics, Circle c, Color color){
        Color tmp = graphics.getColor();
        graphics.setColor(color);
        graphics.fillOval((int) c.getBoundingBox().getLowerLeft().getX(), (int) c.getBoundingBox().getLowerLeft().getY(),
                (int) c.diameter(), (int) c.diameter());
        graphics.setColor(tmp);
    }
}
