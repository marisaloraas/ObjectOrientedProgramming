/**
 * Shape perimeter comparator
 *
 * @author Marisa Loraas
 * @version HW 5, #1
 * @bugs None
 */
package oop.mloraas.hw5.one;

import java.util.Comparator;

public class ShapePerimeterComparator implements Comparator<Shape> {
    public int compare(Shape shapeA, Shape shapeB){
        return shapeA.perimeter() > shapeB.perimeter() ? 1 :
                shapeA.perimeter() < shapeB.perimeter() ? -1 :
                        0;
    }
}
