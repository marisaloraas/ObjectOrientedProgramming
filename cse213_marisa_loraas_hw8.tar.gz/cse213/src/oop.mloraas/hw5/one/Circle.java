/**
 * Circle function from hw2 and hw3 with interface functions
 *
 * @author Marisa Loraas
 * @version HW 5, #1
 * @bugs None
 */

package oop.mloraas.hw5.one;

public class Circle extends Shape{
    private Point center;
    private double radius;

    public Point getCenter() {
        return center;
    }

    public double getRadius() {
        return radius;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * Default circle constructor
     */
    public Circle(){
        this.center = new Point();
        this.radius = 1.0;
    }

    /**
     * Sets circle information based on a Point and radius
     * @param point of circle
     * @param r radius
     */
    public Circle(Point point, double r){
        this.center = point;
        this.radius = r;
    }

    /**
     * finds area of circle
     * @return area of circle
     */
    public double area(){
        return Math.PI * Math.pow(this.radius, 2);
    }

    /**
     * finds perimeter of circle
     * @return perimeter of circle
     */
    public double perimeter(){
        return 2 * Math.PI * this.radius;
    }

    /**
     * finds if a point is in bounds of a circle
     * @param point to see if in bounds
     * @return True if in bounds, false otherwise
     */
    public boolean inBounds(Point point){
        Point a = new Point(this.center.getX() - point.getX(),
                this.center.getY() - point.getY());
        double ans = a.distanceFromOrigin();
        return ans <= this.radius;
    }

    /**
     * Gets the bounding box of the circle
     * @return bounding box
     */
    public Rectangle getBoundingBox(){
        double lowerX = this.center.getX() - this.radius;
        double upperX = this.center.getX() + this.radius;
        double lowerY = this.center.getY() - this.radius;
        double upperY = this.center.getY() + this.radius;
        Point one = new Point(lowerX, lowerY);
        Point two = new Point(upperX, upperY);
        return new Rectangle(one, two);
    }

    /**
     * gets diameter of circle/**
     * Sets position of regular point for Movable Interface
     * @param x x-coordinate
     * @param y y-coordinate
     * @return diameter
     */
    public double diameter(){
        return radius * 2;
    }

    /**
     * gets width of circle
     * @return width
     */
    public double width(){
        return radius * 2;
    }

    /**
     * gets height of circle
     * @return height
     */
    public double height(){
        return radius * 2;
    }

    /**
     * Sets position of regular point for Movable Interface
     * @param x x-coordinate
     * @param y y-coordinate
     */
    public void setPosition(double x, double y){
        this.center.setPosition(x, y);
    }

    /**
     * Sets Polar position for Movable Interface
     * @param r radius
     * @param a angle
     */
    public void setPolar(double r, double a){
        this.center.setPolar(r, a);
    }

    /**
     * Moves Coordinate based on input for Movable Interface
     * @param x amount to move x coordinate
     * @param y amount to move y coordinate
     */
    public void move(double x, double y){
        this.center.move(x, y);
    }

    /**
     * Sets Polar position for Movable Interface
     * @param r radius
     * @param a angle
     */
    public void movePolar(double r, double a){
        this.center.movePolar(r, a);
    }

    /**
     * makes a deep clone
     * @return clone of object
     * @throws CloneNotSupportedException
     */
    public Circle clone() throws CloneNotSupportedException{
        Circle copy = (Circle)super.clone();
        copy.center = (Point)center.clone();
        return copy;
    }
}
