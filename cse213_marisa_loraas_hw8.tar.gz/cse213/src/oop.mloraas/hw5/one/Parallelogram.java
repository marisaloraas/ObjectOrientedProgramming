/**
 * Parallelogram function from hw3
 *
 * @author Marisa Loraas
 * @version HW 5, #1
 * @bugs None
 */
package oop.mloraas.hw5.one;

public class Parallelogram extends Rectangle{
    private double skewAngle;

    public double getSkewAngle(){
        return skewAngle;
    }

    /**
     * Default setter for parallelogram
     */
    Parallelogram(){
        super();
        this.skewAngle = Math.PI / 2;
    }

    /**
     * Sets parameters for parallelogram
     * @param ll lower left point
     * @param ur upper right point
     * @param angle skew angle
     */
    public Parallelogram(Point ll, Point ur, double angle){
        super(ll, ur);
        double y = this.getUpperRight().getY() - this.getLowerLeft().getY();
        double x = this.getUpperLeft().getX() - this.getLowerLeft().getX();
        if(angle < Math.PI && angle > Math.atan2(y,x))
            this.skewAngle = angle;
        else
            this.skewAngle = Math.PI / 2;
    }

    /**
     * Calculates the base length
     * @return base length
     */
    public double baseLength(){
        return Math.abs((this.getUpperRight().getY() - this.getLowerLeft().getY()) / Math.tan(this.skewAngle));
    }

    /**
     * Gets lower right point
     * @return lower right point
     */
    @Override
    public Point getLowerRight(){
        double var1 = this.getUpperRight().getX() + baseLength();
        return new Point(var1, this.getUpperRight().getY());
    }

    /**
     * Gets Upper left point
     * @return upper left point
     */
    @Override
    public Point getUpperLeft(){
        double var1 = this.getLowerLeft().getX() + baseLength();
        return new Point(var1, this.getUpperRight().getY());
    }

    /**
     * gets width of parallelogram
     * @return width
     */
    @Override
    public double width(){
        return this.getUpperRight().getX() - this.getUpperLeft().getX() - baseLength();
    }

    /**
     * calculates area of a parallelogram
     * @return area
     */
    @Override
    public double area(){
        return width() * (this.getUpperRight().getY() - this.getLowerLeft().getY());
    }

    /**
     * calculates perimeter of parallelogram
     * @return perimeter
     */
    @Override
    public double perimeter(){
        return 2 * ((this.getUpperRight().getX() - this.getLowerLeft().getX()) +
                ((this.getUpperRight().getY() - this.getLowerLeft().getY()))/Math.sin(this.skewAngle));
    }

    /**
     * Finds if a point is in bounds of a parallelogram
     * @param point point on graph
     * @return True or False if in bounds
     */
    @Override
    public boolean inBounds(Point point){
        double xBoundL = (this.getUpperLeft().getY() - this.getLowerLeft().getY() / baseLength())*
                (point.getX() - this.getLowerLeft().getX());
        double xBoundR =(this.getUpperLeft().getY() - this.getLowerLeft().getY() / baseLength())*
                (point.getX() - this.getLowerRight().getX());;
        double yBoundT = point.getY() - this.getLowerLeft().getY();
        double yBoundB = point.getY() - this.getUpperLeft().getY();
        return (yBoundB <= xBoundL) && (yBoundT >= xBoundR);
    }
}

