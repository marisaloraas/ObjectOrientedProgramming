/**
 *Builds analog clock Frame
 *
 * @author Marisa Loraas
 * @version HW 8, #1
 * @bugs None
 */

package oop.mloraas.hw8.one;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.TimeZone;

public class ClockFrame extends JFrame {

    private ClockFace clock = new ClockFace();
    private JLabel tzLabel = new JLabel("Mountain Standard Time");

    /**
     * default constructor for clockframe
     */
    public ClockFrame() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(clock, BorderLayout.CENTER);

        JPanel upPanel = new JPanel();
        upPanel.add(tzLabel);
        this.add(upPanel, BorderLayout.NORTH);

        JButton one = new JButton("American/Denver");
        JButton two = new JButton("Europe/London");
        JButton three = new JButton("Asia/Taipei");
        JPanel panel = new JPanel();

        one.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TimeZone timeZone = TimeZone.getTimeZone("American/Denver");
                clock.setTimeZone(timeZone);
                tzLabel.setText("American/Denver");
            }
        });
        two.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TimeZone timeZone = TimeZone.getTimeZone("Europe/London");
                clock.setTimeZone(timeZone);
                tzLabel.setText("Europe/London");
            }
        });
        three.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TimeZone timeZone = TimeZone.getTimeZone("Asia/Taipei");
                clock.setTimeZone(timeZone);
                tzLabel.setText("Asia/Taipei");
            }
        });
        panel.add(one);
        panel.add(two);
        panel.add(three);
        this.add(panel, BorderLayout.SOUTH);
        this.pack();
        this.setVisible(true);
    }

    public static void main(String[] args) {
        ClockFrame frame = new ClockFrame();
        ActionListener al = new ActionListener() {
            public void actionPerformed(ActionEvent aE) {
                frame.clock.tick();
            }
        };
        Timer tm = new Timer(1000, al);
        tm.start();
    }
}

