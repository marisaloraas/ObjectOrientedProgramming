/**
 *Stone enumeration Class
 *
 * @author Marisa Loraas
 * @version HW 8, #2
 * @bugs None
 */
package oop.mloraas.hw8.two;
import java.awt.*;

public enum Stone {
    EMPTY, BLACK, WHITE;

    /**
     * Decides stone color based it enumeration value
     * @return color of stone
     */
    public Color getColor(){
        if(ordinal() == BLACK.ordinal())
            return Color.BLACK;
        else if (ordinal() == WHITE.ordinal())
            return Color.WHITE;
        else
            return null;
    }
}
