/**
 *Builds the Ai for a player to go up against in Gomoku
 *
 * @author Marisa Loraas
 * @version HW 8, #2
 * @bugs None
 */
package oop.mloraas.hw8.two;

public class GomokuAI implements GoPlayer{
    /**
     * checks to see if there is a winner
     * @param stone goboard with all stones on table at that moment
     * @return winner color
     */
    @Override
    public Stone checkWinner(Stone[][] stone) {
        boolean winnerBlack = false;
        boolean winnerWhite = false;
        for(int i = 0; i < 19; i++){
            for(int j = 0; j < 19; j++){
                if(stone[i][j] == Stone.BLACK){
                    if(horizontal(i, j, stone, Stone.BLACK) || vertical(i, j, stone, Stone.BLACK)
                    || diagonal_up(i, j, stone, Stone.BLACK) || diagonal_down(i, j, stone, Stone.BLACK))
                        winnerBlack = true;
                }
                if(stone[i][j] == Stone.WHITE){
                    if(horizontal(i, j, stone, Stone.WHITE) || vertical(i, j, stone, Stone.WHITE)
                            || diagonal_up(i, j, stone, Stone.WHITE) || diagonal_down(i, j, stone, Stone.WHITE))
                        winnerWhite = true;
                }
            }
        }
        if(winnerBlack)
            return Stone.BLACK;
        else if(winnerWhite)
            return Stone.WHITE;
        else
            return Stone.EMPTY;
    }

    /**
     * determines if there is a horizontal win or not
     * @param i row
     * @param j column
     * @param stones board of stones
     * @param color color of stones to look for
     * @return horizontal win (True or False)
     */
    private boolean horizontal(int i, int j, Stone[][] stones, Stone color){
        if(stones[i++][j] == color)
            if(stones[i + 2][j] == color)
                if(stones[i + 3][j] == color)
                    //if(stones[i + 4][j] == color)
                        return true;

        return false;
    }

    /**
     * determines if there is a vertical win or not
     * @param i row
     * @param j column
     * @param stones board of stones
     * @param color color of stones to look for
     * @return horizontal win (True or False)
     */
    private boolean vertical(int i, int j, Stone[][] stones, Stone color){
        if(stones[i][j++] == color)
            if(stones[i][j + 2] == color)
                if(stones[i][j + 3] == color)
                    //if(stones[i][j + 4] == color)
                        return true;

        return false;
    }

    /**
     * determines if there is a diagonal up win or not
     * @param i row
     * @param j column
     * @param stones board of stones
     * @param color color of stones to look for
     * @return horizontal win (True or False)
     */
    private boolean diagonal_up(int i, int j, Stone[][] stones, Stone color){
        if(i < 5)
            return false;
        if(stones[i--][j++] == color)
            if(stones[i - 2][j + 2] == color)
                if(stones[i - 3][j + 3] == color)
                    //if(stones[i - 4][j + 4] == color)
                        return true;

        return false;
    }

    /**
     * determines if there is a diagonal down win or not
     * @param i row
     * @param j column
     * @param stones board of stones
     * @param color color of stones to look for
     * @return horizontal win (True or False)
     */
    private boolean diagonal_down(int i, int j, Stone[][] stones, Stone color){
        if(stones[i++][j++] == color)
            if(stones[i+2][j+2] == color)
                if(stones[i+3][j+3] == color)
                    //if(stones[i+4][j+4] == color)
                        return true;

        return false;
    }

    /**
     * Ai moves
     * @param stone stone board
     * @return coordinates for AI to place stone
     */
    @Override
    public int[] getMove(Stone[][] stone){
        int[] coordinates = new int[2];
        for(int i = 0; i < 19; i++){
            for(int j = 0; j < 19; j++) {
                if(stone[i][j] == Stone.EMPTY) {
                    coordinates[0] = i;
                    coordinates[1] = j;
                    return  coordinates;
                }
            }
        }
        return coordinates;
    }
}
