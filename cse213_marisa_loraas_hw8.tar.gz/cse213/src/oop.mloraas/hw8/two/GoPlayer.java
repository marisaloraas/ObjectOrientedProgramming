/**
 *Interface for Gomoku AI
 *
 * @author Marisa Loraas
 * @version HW 8, #2
 * @bugs None
 */
package oop.mloraas.hw8.two;

public interface GoPlayer {
    public Stone checkWinner(Stone[][] stone);
    public int[] getMove(Stone[][] stone);
}
