/**
 *Builds Gomoku Board
 *
 * @author Marisa Loraas
 * @version HW 8, #2
 * @bugs None
 */
package oop.mloraas.hw8.two;

import oop.mloraas.hw5.one.Circle;
import oop.mloraas.hw5.one.Point;
import oop.mloraas.hw7.one.DrawShape;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;


public class GomokuBoard extends JComponent {
    private GoPlayer ai;
    private Stone[][] stones = new Stone[19][19];
    private int blackScore;
    private int whiteScore;
    private boolean gameOver;

    public int getBlackScore() {
        return blackScore;
    }

    public int getWhiteScore() {
        return whiteScore;
    }

    public boolean getGameOver() {
        return gameOver;
    }

    /**
     * Default constructor for GomokuBoard
     * @param ai AI
     */
    public GomokuBoard(GoPlayer ai) {
        this.ai = ai;
        this.setPreferredSize((new Dimension(720, 720)));
        this.blackScore = 0;
        this.whiteScore = 0;
        this.gameOver = false;
        PlayHandler player = new PlayHandler();
        for (int i = 0; i < 19; i++) {
            for (int j = 0; j < 19; j++)
                this.stones[i][j] = Stone.EMPTY;
        }
        addMouseListener(player);
    }

    /**
     * Builds the go board graphic
     *
     * @param graphics graphics
     */
    public void paintComponent(Graphics graphics) {
        BufferedImage bufferedImage = null;
        try {
            bufferedImage = ImageIO.read(new File("bamboo.jpg"));
        } catch (Exception e) {
            System.out.println("Background Image not found");
        }

        Graphics2D graphics2D = (Graphics2D) graphics;
        if (bufferedImage != null)
            graphics2D.drawImage(bufferedImage, 0, 0, null);

        oop.mloraas.hw5.one.Rectangle board = new oop.mloraas.hw5.one.Rectangle(35, 35);
        for (int i = 0; i < 18; i++) {
            for (int j = 0; j < 18; j++) {
                board.setPosition(45 + i * 35, 45 + j * 35);
                DrawShape.drawRectangle(graphics2D, board, Color.BLACK);
            }
        }

        Circle stone = new Circle(new oop.mloraas.hw5.one.Point(0, 0), 16);
        for (int i = 0; i <= 18; i++) {
            for (int j = 0; j <= 18; j++) {
                if (this.stones[i][j] != Stone.EMPTY) {
                    stone.setCenter(new Point(45 + i * 35, 45 + j * 35));
                    DrawShape.drawCircle(graphics2D, stone, this.stones[i][j].getColor());
                }
            }
        }
    }

    /**
     * Determines if black player can place their piece in a particular place
     * @param i Row
     * @param j Column
     * @return valid play or not (true or false)
     */
    public boolean playBlack(int i, int j) {
        if (!this.gameOver) {
            if (i > 18 || j > 18 || i < 0 || j < 0)
                return false;
            else if (stones[i][j] != Stone.EMPTY)
                return false;
            else {
                this.stones[i][j] = Stone.BLACK;
                repaint();
                return true;
            }
        } else
            return false;
    }

    /**
     * Determines if white player can place their piece in a particular place
     * @return valid play or not (true or false)
     */
    public boolean playWhite(){
        int[] plays = ai.getMove(stones);
        if(!this.gameOver){
            if(stones[plays[0]][plays[1]] != Stone.EMPTY)
                return false;
            else if(plays[0] > 18 || plays[0] < 0 || plays[1] > 18 || plays[1] < 0)
                return false;
            else{
                this.stones[plays[0]][plays[1]]= Stone.WHITE;
                repaint();
                return true;
            }
        }else
            return false;
    }

    /**
     * resets the board for a new game
     */
    public void resetGame(){
        for(int i = 0; i < 19; i++){
            for(int j = 0; j < 19; j++)
                this.stones[i][j] = Stone.EMPTY;
        }
        this.gameOver = false;
        repaint();
    }

    /**
     * Play handler class that determines a persons move based on where they click on the board
     */
    private class PlayHandler extends MouseAdapter {

        /**
         * Plays game
         * @param event where user clicks on board
         */
        @Override
        public void mouseClicked(MouseEvent event){
            int x = (int) Math.floor((event.getX() - 27.5) / 35.0);
            int y = (int) Math.floor((event.getY() - 27.5) / 35.0);

            if(!playBlack(x, y))
                return;
            else{
                if (ai.checkWinner(stones) == Stone.BLACK){
                    blackScore++;
                    gameOver = true;
                }else{
                    playWhite();
                    if(ai.checkWinner(stones) == Stone.WHITE){
                        whiteScore++;
                        gameOver = true;
                    }
                }
            }
        }
    }
}


