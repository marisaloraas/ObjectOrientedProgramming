/**
 *Build Gomoku Frame
 *
 * @author Marisa Loraas
 * @version HW 8, #2
 * @bugs None
 */
package oop.mloraas.hw8.two;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GomokuFrame extends JFrame {
    private GomokuBoard board;
    private JLabel blackScore;
    private JLabel whiteScore;

    /**
     * Contructs the Gomoku frame
     */
    public GomokuFrame(){
        JPanel panel = new JPanel();
        GomokuBoard goboard = new GomokuBoard(new GomokuAI());
        add(goboard);
        this.board = goboard;
        panel.setBackground(Color.decode("#ffd294"));
        blackScore = new JLabel("Black: " + board.getBlackScore(), SwingConstants.CENTER);
        whiteScore = new JLabel("White: " + board.getWhiteScore(), SwingConstants.CENTER);
        blackScore.setForeground(Color.BLACK);
        blackScore.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 32));
        whiteScore.setForeground(Color.WHITE);
        whiteScore.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 32));
        panel.setLayout(new GridLayout(1, 2));
        panel.add(blackScore);
        panel.add(whiteScore);
        add(panel, BorderLayout.NORTH);

        JButton newgame = new JButton("New Game");
        add(newgame, BorderLayout.SOUTH);

        ActionListener restartEvent = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                board.resetGame();
            }
        };

        newgame.addActionListener(restartEvent);
        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                blackScore.setText("Black: " + board.getBlackScore());
                whiteScore.setText("White: " + board.getWhiteScore());
                repaint();
            }
        };

        board.addMouseListener(mouseAdapter);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args){
        GomokuFrame frame = new GomokuFrame();
    }
}
