/**
 * Tests the getDuration() function form Beat.java
 *
 * @author Marisa Loraas
 * @version HW 4, #1
 * @bugs None
 */
package oop.mloraas.hw4.one.Testing;

import oop.mloraas.hw4.one.Beat;
import org.junit.Test;

import static org.junit.Assert.*;

public class BeatTest {

    @Test
    public void getDurationWhole() {
        double expected = 2;
        double actual = Beat.WHOLE.getDuration(120);
        assertEquals("getDuration() does not output expected number", expected, actual, 0.1);
    }

    @Test
    public void getDurationSixteenth(){
        double expected = 0.125;
        double actual = Beat.SIXTEENTH.getDuration(120);
        assertEquals("getDuration() does not outeput expected number", expected, actual, 0.1);
    }
}