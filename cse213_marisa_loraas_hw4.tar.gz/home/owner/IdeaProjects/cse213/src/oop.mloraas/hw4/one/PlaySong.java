/**
 * Sets note based on Pitch and Beat enumeration classes
 *
 * @author Marisa Loraas
 * @version HW 4, #1
 * @bugs None
 */

package oop.mloraas.hw4.one;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

//Change
public class PlaySong {
    /**
     * Translates notes and tempo to a frequency and duration
     * @param notes set of notes
     * @param tempo tempo of song
     */
    public static void playSong(ArrayList<Note> notes, int tempo){
        for(Note note : notes) {
            double f = note.getFrequency();
            double dur = note.getLength().getDuration(tempo);
            System.out.println(String.format("%f, %f, %s", f, dur, note.toString()));
            Tone.playTone(f, dur);
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<Note> notes = new ArrayList<>();
        String[] split;

        Scanner in = new Scanner(new FileReader("song.txt"));

        while(in.hasNext()) {
            split = in.nextLine().split(" ");
            if(!split[1].isEmpty()) {
                for(Beat b: Beat.values()){
                    if(split[1].equals(b.toString()))
                        notes.add(new Note(split[0], b));
                }
            }
            //System.out.println(split[0] + ";" + split[1]);
        }
        playSong(notes, 120);
    }
}
