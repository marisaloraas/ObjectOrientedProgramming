/**
 * Sets note based on Pitch and Beat enumeration classes
 *
 * @author Marisa Loraas
 * @version HW 4, #1
 * @bugs None
 */

package oop.mloraas.hw4.one;

public class Note {

    private Pitch note;
    private int octave;
    private Beat length;

    public Pitch getNote() {
        return note;
    }

    public int getOctave() {
        return octave;
    }

    public Beat getLength() {
        return length;
    }

    public void setNote(Pitch note) {
        this.note = note;
    }

    public void setOctave(int octave) {
        this.octave = octave;
    }

    public void setLength(Beat length) {
        this.length = length;
    }

    /**
     * default set for a note
     */
    public Note() {
        this.note = Pitch.C;
        this.octave = 4;
        this.length = Beat.QUARTER;
    }

    /**
     * sets note based in given inputs
     * @param note   pitch of note
     * @param octave octave of note
     * @param length beat
     */
    public Note(Pitch note, int octave, Beat length) {
        this.length = length;
        this.note = note;
        if (octave >= 1 && octave <= 9) {
            if ((note == Pitch.GSHARP || note == Pitch.A || note == Pitch.ASHARP || note == Pitch.B)
                    && octave == 9)
                this.octave = 8;
            else
                this.octave = octave;
        } else
            this.octave = 8;

    }

    /**
     * gets the SPN string (note and its octave)
     * @return SPN string
     */
    public String getSPN() {
        return this.note.toString() + Integer.toString(this.octave);
    }

    /**
     * Sets the note and octave based on the SPN string
     * @param spn SPN String
     */
    public void setSPN(String spn) {
        if (spn.matches("(([CDFGA]#?|[EB])(-1|[0-8])|([CDF]#?|[EG])9)")) {
            if (spn.contains("#")) {
                switch (spn.charAt(0)) {
                    case 'C':
                        this.note = Pitch.CSHARP;
                        break;
                    case 'D':
                        this.note = Pitch.DSHARP;
                        break;
                    case 'F':
                        this.note = Pitch.FSHARP;
                        break;
                    case 'G':
                        this.note = Pitch.GSHARP;
                        break;
                    case 'A':
                        this.note = Pitch.ASHARP;
                        break;
                }
            } else {
                switch (spn.charAt(0)) {
                    case 'C':
                        this.note = Pitch.C;
                        break;
                    case 'D':
                        this.note = Pitch.D;
                        break;
                    case 'E':
                        this.note = Pitch.E;
                        break;
                    case 'F':
                        this.note = Pitch.F;
                        break;
                    case 'G':
                        this.note = Pitch.G;
                        break;
                    case 'A':
                        this.note = Pitch.A;
                        break;
                    case 'B':
                        this.note = Pitch.B;
                        break;
                }
            }
            this.octave = Integer.parseInt(spn.replaceAll("[^0-9]", ""));
        }
    }

    /**
     * Sets note based on SPN string and beat
     * @param spn SPN string
     * @param length Beat
     */
    public Note(String spn, Beat length){
        setSPN(spn);
        this.length = length;
    }

    /**
     *  gets the MDI number
     * @return MDI number
     */
    public int getMIDI(){
        return 69 + this.note.getOffset() + (12 *(this.octave - 4));
    }

    /**
     * sets the octave and note based on MIDI number
     * @param midi MIDI number
     */
    public void setMIDI(int midi){
        if(midi <= 127 && midi >= 0){
            this.octave = Math.floorDiv(midi, 12) - 1;
            this.note = Pitch.values()[midi%12];
        }
    }

    /**
     * Sets beat, pitch, and octave based on MIDI input
     * @param midi MIDI number
     * @param length beat
     */
    public Note(int midi, Beat length){
        this.length = length;
        setMIDI(midi);
    }

    /**
     * gets the frequency based on the MIDI
     * @return Frequency
     */
    public double getFrequency(){
        double x = (getMIDI() - 69) / 12.0;
        return 440 * Math.pow(2, x);
    }

    /**
     * changes frequency to MIDI number
     * @param frequency frequency
     */
    public void setFrequency(double frequency){
        double x = Math.log(frequency / 440.0);
        double y = Math.log(2);
        setMIDI((int) Math.round(12 * (x/y) + 69));
    }

    /**
     * Sets beat, pitch, and octave based in frequency input
     * @param frequency frequency
     * @param length Beat
     */
    public Note(double frequency, Beat length){
        this.length = length;
        setFrequency(frequency);
    }

    /**
     * String of SPN number and Beat
     * @return SPN (beat)
     */
    public String toString(){
        return getSPN() + " " + this.length.toString();
    }
}
