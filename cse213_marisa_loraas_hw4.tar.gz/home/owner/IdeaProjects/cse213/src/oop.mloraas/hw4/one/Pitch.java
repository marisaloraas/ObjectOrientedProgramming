/**
 * Enumeration Class for Pitch
 *
 * @author Marisa Loraas
 * @version HW 4, #1
 * @bugs None
 */
package oop.mloraas.hw4.one;

public enum Pitch {
    C,
    CSHARP,
    D,
    DSHARP,
    E,
    F,
    FSHARP,
    G,
    GSHARP,
    A,
    ASHARP,
    B;

    /**
     * sets note to correct coordinating index from pdf
     * @return offset of note
     */
    public int getOffset(){
        return this.ordinal() - Pitch.A.ordinal();
    }

    /**
     * Prints out the note name with # instead of SHARP
     * @return note name
     */
    public String toString() {
        String name = this.name();
        return name.replace("SHARP", "#");
    }
}
