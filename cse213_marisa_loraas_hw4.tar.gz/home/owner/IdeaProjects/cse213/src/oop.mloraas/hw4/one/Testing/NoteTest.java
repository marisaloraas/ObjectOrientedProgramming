/**
 * Tests the five note constructors from Note.java
 *
 * @author Marisa Loraas
 * @version HW 4, #1
 * @bugs None
 */
package oop.mloraas.hw4.one.Testing;

import oop.mloraas.hw4.one.Beat;
import oop.mloraas.hw4.one.Note;
import oop.mloraas.hw4.one.Pitch;
import org.junit.Test;

import static org.junit.Assert.*;

public class NoteTest {

    @Test
    public void note1(){
        Pitch pExpected = Pitch.C;
        Pitch pAcutal = new Note().getNote();
        assertEquals("Pitch is not set correctly in the first note constructor", pExpected, pAcutal);

        int oExpected = 4;
        int oAcutal = new Note().getOctave();
        assertEquals("Octave is not set correctly in the first note constructor", oExpected, oAcutal);

        Beat lExpected = Beat.QUARTER;
        Beat lActual = new Note().getLength();
        assertEquals("Beat is not set correctly in the first note constructor", lExpected, lActual);
    }

    @Test
    public void note2(){
        int expected = 8;
        int actual = new Note(Pitch.ASHARP, 9, Beat.WHOLE).getOctave();
        assertEquals("Octave is not set correctly in the second note constructor", expected, actual);
    }

    @Test
    public void note3(){
        Pitch pExpected = Pitch.D;
        Pitch pActual = new Note("D7", Beat.QUARTER).getNote();
        assertEquals("Pitch is not set correctly in the third note constructor", pExpected, pActual);

        int oExpected = 7;
        int oActual = new Note("D7", Beat.QUARTER).getOctave();
        assertEquals("Octave is not set correctly in the forth not constructor", oExpected, oActual);
    }

    @Test
    public void note4(){
        Pitch pExpected = Pitch.F;
        Pitch pActual = new Note(77, Beat.QUARTER).getNote();
        assertEquals("Pitch is not set correctly in the third note constructor", pExpected, pActual);

        int oExpected = 5;
        int oActual = new Note(77, Beat.QUARTER).getOctave();
        assertEquals("Octave is not set correctly in the forth not constructor", oExpected, oActual);
    }

    @Test
    public void note5(){
        //207.65 = G#3
        Pitch pExpected = Pitch.GSHARP;
        Pitch pActual = new Note(207.65, Beat.WHOLE).getNote();
        assertEquals("Pitch is not set correctly in the third note constructor", pExpected, pActual);

        int oExpected = 3;
        int oActual = new Note(207.65, Beat.WHOLE).getOctave();
        assertEquals("Octave is not set correctly in the forth not constructor", oExpected, oActual);
    }
}