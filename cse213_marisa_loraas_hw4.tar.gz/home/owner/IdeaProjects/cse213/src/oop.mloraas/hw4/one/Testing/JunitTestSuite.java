/**
 * Tests the getDuration() function form Beat.java
 *
 * @author Marisa Loraas
 * @version HW 4, #1
 * @bugs None
 */

package oop.mloraas.hw4.one.Testing;

import oop.mloraas.hw4.one.Testing.BeatTest;
import oop.mloraas.hw4.one.Testing.NoteTest;
import oop.mloraas.hw4.one.Testing.PitchTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        BeatTest.class,
        NoteTest.class,
        PitchTest.class
})
public class JunitTestSuite {

}
