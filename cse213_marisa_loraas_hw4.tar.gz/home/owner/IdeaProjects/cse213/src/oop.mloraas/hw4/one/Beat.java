/**
 * Enumeration Class for Beat
 *
 * @author Marisa Loraas
 * @version HW 4, #1
 * @bugs None
 */
package oop.mloraas.hw4.one;

public enum Beat {
    WHOLE,
    THREEQUARTER,
    HALF,
    THREEEIGHTH,
    QUARTER,
    THREESIXTEENTH,
    EIGHTH,
    SIXTEENTH;

    private double[] time = { 4, 3, 2, 3.0 / 2.0, 1, 3.0 / 4.0, 1.0 / 2.0, 1.0 / 4.0};
    private String[] beats = {"(1)", "(3/4)", "(1/2)", "(3/8)", "(1/4)", "(3/16)", "(1/8)", "(1/16)"};

    /**
     * gets beat of note
     * @return beat
     */
    public double getBeats(){
        return this.time[this.ordinal()];
    }

    /**
     * gets Duration of beat based on beat and tempo
     * @param tempo tempo of piece
     * @return duration
     */
    public double getDuration(int tempo){
        return (60 * this.getBeats()) / (double) tempo;
    }

    /**
     * prints the beat in number form
     * @return beat
     */
    public String toString(){
        return beats[this.ordinal()];
    }
}
