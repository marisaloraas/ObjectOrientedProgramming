/**
 * Tests the getOffset() function from Pitch.java
 *
 * @author Marisa Loraas
 * @version HW 4, #1
 * @bugs None
 */
package oop.mloraas.hw4.one.Testing;

import oop.mloraas.hw4.one.Pitch;
import org.junit.Test;

import static org.junit.Assert.*;

public class PitchTest {

    @Test
    public void getOffsetA() {
        int expected = 0;
        int actual = Pitch.A.getOffset();
        assertEquals("getOffset() does not return expected value", expected, actual);
    }

    @Test
    public void getOffsetC(){
        int expected = -9;
        int actual = Pitch.C.getOffset();
        assertEquals("getOffset() does not return expected value", expected, actual);
    }
}