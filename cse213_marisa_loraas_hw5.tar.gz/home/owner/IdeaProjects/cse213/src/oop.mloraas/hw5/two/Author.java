/**
 * Sets the author for bibliography citations
 * from hw3 adapted for comparable function
 *
 * @author Marisa Loraas
 * @version HW 5, #2
 * @bugs None
 */

package oop.mloraas.hw5.two;

public class Author implements Comparable<Author>{
    private String lastName;
    private String firstName;
    private String middleInitial;

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    /**
     * Sets the Auhors name
     * @param fn first name
     * @param ln last name
     * @param mi middle Initial
     */
    public Author(String fn, String ln, String mi){
        this.firstName = fn;
        this.lastName = ln;
        this.middleInitial = mi;
    }

    /**
     * Splits up a string to Set authors name
     * @param full authors full name
     */
    public Author(String full){
        String[] split = full.strip().split(" ");
        if(split.length == 3){
            this.firstName = split[0];
            this.middleInitial = split[1].charAt(0) + ".";
            this.lastName = split[2];
        }else if(split.length == 2){
            this.firstName = split[0];
            this.middleInitial = "";
            this.lastName = split[1];
        }
    }

    /**
     * gets the citation format for an author in a bibilography (i replaced this with get citation)
     * @return citation
     */
    public String toString(){
        return this.lastName + ", " + this.firstName.charAt(0) + ". " + this.middleInitial;
    }

    /**
     * Splits up several authors into an author array
     * @param author strings of authors
     * @return array of split authors
     */
    public static Author[] splitAuthors(String author){
        author = author.replaceAll("and", "");
        String list[] = author.split(",");
        Author[] authors = new Author[list.length];
        for(int i = 0; i < authors.length; i++)
            authors[i] = new Author(list[i].trim());

        return authors;
    }

    /**
     * Compare to function for authors
     * @param a author to compare to
     * @return 0 if equal, 1 or -1 otherwise
     */
    public int compareTo(Author a){
        if(this.lastName.equals(a.lastName)) {
            if(this.firstName.equals(a.firstName))
                return this.middleInitial.compareTo(a.middleInitial);
                return this.firstName.compareTo(a.firstName);
            }
        return this.lastName.compareTo(a.lastName);
    }
}
