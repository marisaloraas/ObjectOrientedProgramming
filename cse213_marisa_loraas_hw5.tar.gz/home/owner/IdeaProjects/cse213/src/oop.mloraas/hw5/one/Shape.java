/**
 * abstract class to Movable interface
 *
 * @author Marisa Loraas
 * @version hw5, #1
 * @bugs none
 */

package oop.mloraas.hw5.one;

public abstract class Shape implements Movable, Cloneable{

    public abstract double area();
    public abstract double perimeter();
    public abstract boolean inBounds(Point p);
}

