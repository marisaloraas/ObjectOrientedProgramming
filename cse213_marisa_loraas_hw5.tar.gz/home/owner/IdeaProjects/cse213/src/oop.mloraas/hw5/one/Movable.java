package oop.mloraas.hw5.one;

public interface Movable {
    public void setPosition(double x, double y);
    public void setPolar(double r, double a);
    public void move(double a, double y);
    public void movePolar(double r, double a);
}
