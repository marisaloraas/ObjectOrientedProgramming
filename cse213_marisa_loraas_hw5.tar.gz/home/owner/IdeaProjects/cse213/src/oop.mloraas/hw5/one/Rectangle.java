/**
 * Rectangle function from hw1, hw2, and hw3
 *with interface
 *
 * @author Marisa Loraas
 * @version HW 5, #1
 * @bugs None
 */

package oop.mloraas.hw5.one;

public class Rectangle extends Shape {
    private Point lowerLeft;
    private Point upperRight;

    public Point getLowerLeft() {
        return lowerLeft;
    }

    public Point getUpperRight() {
        return upperRight;
    }

    /**
     * Creates default rectangle at origin for lower left corner
     * and (1,1) for upper right corner
     */
    public Rectangle(){
        this.lowerLeft = new Point();
        this.upperRight = new Point(1,1);
    }

    /**
     * Makes rectangle with specific input for points
     * @param one lower left corner
     * @param two upper right corner
     */
    public Rectangle(Point one, Point two){
        if(one.getY() > two.getY()){
            double temp = one.getY();
            one.setY(two.getY());
            two.setY(temp);
        }
        if(one.compareTo(two) > 0){
            Point temp = one;
            one = two;
            two = temp;
        }
        this.lowerLeft = one;
        this.upperRight = two;
    }

    /**
     * Makes rectangle with specific input for width and height
     * @param w width
     * @param h height
     */
    public Rectangle(double w, double h){
        this.lowerLeft = new Point();
        this.upperRight = new Point(w, h);
    }

    /**
     * Gets the lower right point of the rectangle
     * @return Lower right Point
     */
    public Point getLowerRight(){
        return new Point(this.upperRight.getX(), this.lowerLeft.getY());
    }

    /**
     * Gets the upper left point of the rectangle
     * @return upper left point
     */
    public Point getUpperLeft(){
        return new Point(this.lowerLeft.getX(), this.upperRight.getY());
    }

    /**
     * Finds area of rectangle
     * @return area of rectangle
     */
    public double area(){
        return (this.upperRight.getX() - this.lowerLeft.getX()) *
                (this.upperRight.getY() - this.lowerLeft.getY());
    }

    /**
     * Finds perimeter of rectangle
     * @return perimeter of rectangle
     */
    public double perimeter(){
        return 2 * ((this.upperRight.getX() - this.lowerLeft.getX()) +
                (this.upperRight.getY() - this.lowerLeft.getY()));
    }

    /**
     * Finds if a point is in the bounds of a rectangle
     * @param point point on graph
     * @return true if in bounds, false otherwise
     */
    public boolean inBounds(Point point){
        return (this.lowerLeft.compareTo(point) < 0) &&
                (this.upperRight.compareTo(point) > 0);
    }

    /**
     * gets width of rectangle
     * @return width
     */
    public double width(){
        return this.upperRight.getX() - this.lowerLeft.getX();
    }

    /**
     * return height of rectangle
     * @return height
     */
    public double height(){
        return this.upperRight.getY() - this.lowerLeft.getY();
    }

    /**
     * Sets position of regular point for Movable Interface
     * @param x x-coordinate
     * @param y y-coordinate
     */
    public void setPosition(double x, double y){
        this.lowerLeft.setPosition(x, y);
        this.upperRight.setPosition(x,y);
    }

    /**
     * Sets Polar position for Movable Interface
     * @param r radius
     * @param a angle
     */
    public void setPolar(double r, double a){
        this.lowerLeft.setPolar(r, a);
        this.upperRight.setPolar(r, a);
    }

    /**
     * Moves Coordinate based on input for Movable Interface
     * @param x amount to move x coordinate
     * @param y amount to move y coordinate
     */
    public void move(double x, double y){
        this.lowerLeft.move(x, y);
        this.upperRight.move(x, y);
    }

    /**
     * Moves polar coordinates based on input for Movable Interface
     * @param r move radius
     * @param a move angle
     */
    public void movePolar(double r, double a){
        this.lowerLeft.movePolar(r, a);
        this.upperRight.movePolar(r, a);
    }

    /**
     * makes deep clone
     * @return clone of object
     * @throws CloneNotSupportedException
     */
    public Rectangle clone() throws CloneNotSupportedException{
        Rectangle copy = (Rectangle) super.clone();
        copy.upperRight = (Point) upperRight.clone();
        copy.lowerLeft = (Point) lowerLeft.clone();
        return copy;
    }
}