/**
 * book function from hw3 adapted
 *
 * @author Marisa Loraas
 * @version HW 5, #2
 * @bugs None
 */
package oop.mloraas.hw5.two;


import java.util.Arrays;

public class Book extends Author{
    private Author[] author;
    private String title;
    private int year;
    private String publisher;

    public Author[] getAuthor() {
        return author;
    }

    public String getTitle(){
        return title;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getYear() {
        return year;
    }

    /**
     * default sets the author, title, year, and publisher of a book
     * @param author author of book
     * @param title title of book
     * @param year year book was released
     * @param publisher publisher of book
     */
    public Book(String author, String title, int year, String publisher){
        super(author);
        this.author = splitAuthors(author);
        this.title = title;
        this.year = year;
        this.publisher = publisher;
    }

    /**
     * Converts book information into proper citation form (string)
     * @return citation
     */
    public String toString() {
        return author[0].toString() + ", " + title + "., " + year + "\n" + publisher;
    }
}
