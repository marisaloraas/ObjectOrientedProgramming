/**
 * Reads in files to organize books by author, title,
 * and year
 *
 * @author Marisa Loraas
 * @version HW 5, #2
 * @bugs None
 */
package oop.mloraas.hw5.two;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;


public class Library {
    public static void main(String[] args){
        FileReader read = null;
        Scanner in = new Scanner(System.in);
        String file;
        ArrayList<Book> book = new ArrayList<>();
        String line;
        String[] split;
        String publisher;

        while(read == null){
            System.out.print("Name of file: ");
            file = in.nextLine();
            try{
                read = new FileReader(file);
                break;
            }catch(IOException e){
                System.out.println("Error! Cannot open file: " + file);
            }
        }

       in = new Scanner(read);
        while(in.hasNextLine()){
            line = in.nextLine();
            split = line.split(", ");
            publisher = in.nextLine();
            Book b = new Book(split[0], split[1], Integer.parseInt(split[2]), publisher);
            book.add(b);
        }

        String sortby;
        System.out.println("Sort collection by [author/title/year]");
        in = new Scanner(System.in);
        sortby = in.nextLine();

        switch (sortby){
            case "author":
                Collections.sort(book, Author::compareTo);
                break;
            case "title":
                Collections.sort(book, new SortTitle());
                break;
            case "year":
                Collections.sort(book, new SortYear());
                break;
            default:
                System.out.println("Not a viable option");
                break;
        }

        for (Book b: book)
            System.out.println(b);

    }
}


class SortTitle implements Comparator<Book> {
    @Override
    public int compare(Book b1, Book b2) {
        return b1.getTitle().compareTo(b2.getTitle());
    }
}

class SortYear implements Comparator<Book>{
    @Override
    public int compare(Book b1, Book b2){
        return Integer.compare(b1.getYear(), b2.getYear());
    }
}

