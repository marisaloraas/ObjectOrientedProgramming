/**
 * Prints first 100 integers, but if its a multiple of 3 it prints Fizz, mulitples
 * of 4 prints Razz, and mulitples of 5 prints Buzz
 *
 * @author Marisa Loraas
 * @version HW 0, #1
 * @bugs None
 */

package oop.mloraas.hw0.one;

public class Fizz{
    public static void main (String[] args){
        for(int i = 1; i <= 100; i++){
            if((i % 3 == 0) && (i % 4 == 0) && (i % 5 == 0)){
                System.out.println("FizzRazzBuzz");
            }else if((i % 3 == 0) && (i % 4 == 0)){
                System.out.println("FizzRazz");
            }else if((i % 3 == 0) && (i % 5 == 0)){
                System.out.println("FizzBuzz");
            }else if((i % 4 == 0) && (i % 5 == 0)){
                System.out.println("RazzBuzz");
            }else if(i % 3 == 0){
                System.out.println("Fizz");
            }else if(i % 4 == 0){
                System.out.println("Razz");
            }else if(i % 5 == 0){
                System.out.println("Buzz");
            }else{
                System.out.println(i);
            }
        }
    }
}
