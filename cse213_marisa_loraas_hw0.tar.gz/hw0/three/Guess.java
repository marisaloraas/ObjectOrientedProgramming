/**
 * This class uses a binary search algorithm to guess what number the
 * user is thinking of when promted to give a lower bound and an upper
 * bound
 *
 * @author Marisa Loraas
 * @version HW 0, #3
 * @bugs Prints the first guess twice (but only the first statement),
 * nobody I've asked can figure it out either.
 */

package oop.mloraas.hw0.three;
import java.util.*;

public class Guess{
    public static void main (String[] args){
        System.out.println("Think of a number!");
        Scanner in = new Scanner(System.in);
        System.out.print("Lower bound: ");
        int lowerbound = in.nextInt();
        System.out.print("Upper bound: ");
        int upperbound = in.nextInt();

        int swap, count = 1, x = 0;

        if(lowerbound > upperbound){
            swap = lowerbound;
            lowerbound = upperbound;
            upperbound = swap;
        }

        String ans = "lt";
        while(!ans.equals("eq")){
            System.out.print("Is it " + (upperbound + lowerbound)/2 + "?  [lt/eq/gt]: ");
            ans = in.nextLine();
            switch(ans){
                case "lt":
                    upperbound = (upperbound + lowerbound)/2;
                    x = upperbound;
                    count++;
                    break;
                case "gt":
                    lowerbound = (upperbound + lowerbound)/2;
                    x = lowerbound;
                    count++;
                    break;
                case "eq":
                    x = (upperbound + lowerbound)/2;
                    System.out.println("It took " + count + " guesses to find the number " + x + "!");
                    break;
            }
        }
    }
}
