/**
 * Plays rock, paper, scissors against player
 *
 * @author Marisa Loraas
 * @version HW 0, #2
 * @bugs None
 */

package oop.mloraas.hw0.two;

import java.util.*;
import java.io.*;

public class RPS{
    public static void main (String[] args){
        Scanner in = new Scanner(System.in);

        int computer  = 0, count = 1;
        String cmove = "ROCK";
        while(computer <= 2) {
            System.out.print("Your move? [rock/paper/scissors]: ");
            String pmove = in.nextLine();
            pmove = pmove.toUpperCase();
            System.out.println(cmove);
            switch (pmove) {
                case "ROCK":
                    switch (cmove) {
                        case "ROCK":
                            System.out.println("Draw!");
                            computer = 0;
                            count++;
                            break;
                        case "PAPER":
                            System.out.println("Computer wins!");
                            computer++;
                            count++;
                            break;
                        case "SCISSORS":
                            System.out.println("Player wins!");
                            computer = 0;
                            count++;
                            break;
                    }
                    break;
                case "PAPER":
                    switch (cmove) {
                        case "ROCK":
                            System.out.println("Player wins!");
                            computer = 0;
                            count++;
                            break;
                        case "PAPER":
                            System.out.println("Draw!");
                            computer = 0;
                            count++;
                            break;
                        case "SCISSORS":
                            System.out.println("Computer wins!");
                            computer++;
                            count++;
                            break;
                    }
                    break;
                case "SCISSORS":
                    switch (cmove) {
                        case "ROCK":
                            System.out.println("Computer wins!");
                            computer++;
                            count++;
                            break;
                        case "PAPER":
                            System.out.println("Player wins!");
                            computer = 0;
                            count++;
                            break;
                        case "SCISSORS":
                            System.out.println("Draw!");
                            computer = 0;
                            count++;
                            break;

                    }
                    break;
                default:
                    System.out.println("Error! Please enter \"rock\" \"paper\" or \"scissors\" ");
                    break;
            }
            if(count == 2){
                cmove = "PAPER";
            }else if(count == 3){
                cmove = "SCISSORS";
                count = 0;
            }else if (count == 1){
                cmove = "ROCK";
            }
        }
    }
}
