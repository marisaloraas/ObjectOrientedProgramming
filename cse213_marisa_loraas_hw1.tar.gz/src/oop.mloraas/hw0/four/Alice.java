/**
 * This class takes in a file alice.txt and outputs that file where every other
 * line is entirely upper case then entirely lowercase into a file called
 * alice_mixed_case.txt
 *
 * @author Marisa Loraas
 * @version HW0, #4
 * @bugs None
 */

package oop.mloraas.hw0.four;
import java.util.*;
import java.io.*;
import java.lang.*;

public class Alice{
    public static void main(String[] args){

        int line = 1;

        try {
            BufferedReader buff = new BufferedReader(new FileReader("alice.txt"));
            PrintWriter output = new PrintWriter("alice_mixed_case.txt");
            Scanner in = new Scanner(buff);
            while(in.hasNextLine()){
                String change = in.nextLine();
                if(change.isEmpty()){
                    change = "\n";
                    output.write(change);
                } else if(line % 2 == 1) {
                    change = change.toUpperCase() + "\n";
                    output.write(change);
                    line++;
                } else if (line % 2 == 0) {
                    change = change.toLowerCase() + "\n";
                    output.write(change);
                    line++;
                }
            }
            in.close();
            output.close();
        } catch (FileNotFoundException e){
            System.out.print(e);
        }


    }
}
