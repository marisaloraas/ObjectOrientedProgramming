/**
 * Tests every functions (not get or set) in the files Point.java
 * Rectangle.java and Circle.java
 *
 * @author Marisa Loraas
 * @version HW 1, #1
 * @bugs None
 */

package oop.mloraas.hw1.one;

import oop.mloraas.hw1.one.Point;
import oop.mloraas.hw1.one.Rectangle;
import oop.mloraas.hw1.one.Circle;

import static java.lang.Boolean.*;

public class Test {

    public static void testPointFunction1(){
        Point pt = new Point();
        if((pt.getX() != 0.0) || (pt.getY() != 0.0))
            System.out.println("1st Point function failed: wrong initialization");
    }

    public static void testPointFunction2(){
        Point pt = new Point(2.0,2.0);
        if((pt.getX() != 2.0) || (pt.getY() != 0.0))
            System.out.println("2nd Point function failed: wrong initialization");
    }

    public static void testPointFunction3(){
        Point pt = new Point(2.0, 2.0);
        Point superpt = new Point(pt);
        if((superpt.getX() != 2.0) || (superpt.getY() != 2.0))
            System.out.println("3rd Point Function failed: wrong initialization");
    }

     public static void testPointDistance(){
        Point pt1 = new Point(0,0);
        Point pt2 = new Point(2 ,2);

        double ans = pt2.distance(pt1);
        if(ans != 2.0)
            System.out.println("testPointDistance failed: wrong value calculated");
    }

    public static void testPointDistanceFromOrigin(){
        Point pt1 = new Point(1,0);
        double ans = pt1.distanceFromOrigin();
        if(ans != 1)
            System.out.println("testPointDistanceFromOrigin failed: wrong value calculated");
    }

    public static void testRectangleFunction1(){
        Rectangle rec = new Rectangle();
        if((rec.getLowerLeftX() != 0.0) || (rec.getLowerLeftY() != 0.0) ||(rec.getUpperRightX() != 1.0) ||
                (rec.getUpperRightY() != 1.0))
            System.out.println("1st Rectangle function failed: wrong initialization");
    }

    public static void testRectangleFunction2(){
        Rectangle rec = new Rectangle(1,2);
        if((rec.getLowerLeftX() != 0) || (rec.getLowerLeftY() != 0) || (rec.getUpperRightX() != 2.0) ||
                (rec.getUpperRightY() != 1.0))
            System.out.println("2nd rectangle function failed: wrong initialization");
    }

    public static void testRectangleFunction3(){
        Rectangle rect = new Rectangle(3, 2, 1, 4);
        double x1 = rect.getLowerLeftX();
        double y1 = rect.getLowerLeftY();
        double x2 = rect.getUpperRightX();
        double y2 = rect.getUpperRightY();

            if (x1 != 1 || y1 != 2)
                System.out.println("testRectangleWrongPoints: Wrong lower left point!");
            if (x2 != 3 || y2 != 4)
                System.out.println("testRectangleWrongPoints: Wrong upper right point!");
    }

    public static void testRectangleArea(){
        Rectangle rec = new Rectangle(0, 3, 0, 3);
        double ans = rec.area();
        if(ans != 9)
            System.out.println("testRectangleArea failed: wrong value calculated");
    }

    public static void testRectanglePerimeter(){
        Rectangle rec = new Rectangle(0, 3, 0, 3);
        double ans = rec.perimeter();
        if (ans != 12)
            System.out.println("testRectanglePerimeter failed: wrong value calculated");
    }

    public static void testRectangleDistanceFromOrigin(){
         Rectangle rec = new Rectangle(1, 3, 1, 3);
         double ans = rec.distanceFromOrigin();
         if(ans != 1)
             System.out.println("testRectangleDistanceFromOrigin failed: wrong value calculated");
    }

    public static void testRectangleInBounds(){
         Rectangle rec = new Rectangle(0, 1, 0, 1);
         boolean ans = rec.inBounds(2, 3);
         if(ans != FALSE)
             System.out.print("testRectangleInBounds failed: wrong boolean type calculated");
    }

    public static void testCircleFunction1(){
        Circle circ = new Circle();
        if((circ.getCenterX() != 0) || (circ.getCenterY() != 0) || (circ.getRadius() != 1.0))
            System.out.print("1st Circle Function failed: wrong initialization");
    }


    public static void testCircleFunction2(){
        Circle circ = new Circle(1, 1, 4);
        if((circ.getCenterX() != 1.0) || (circ.getCenterY() != 1.0) || (circ.getRadius() != 4.0))
            System.out.println("2nd Circle Function failed: wrong initialization");
    }

    public static void testCircleArea(){
         Circle sphere = new Circle(0, 0, 3);
         double ans = sphere.area();
         if(ans != 28.27)
             System.out.println("testCircleArea failed: wrong value calculated");
    }

    public static void testCirclePerimeter(){
         Circle sphere = new Circle(0, 0, 3);
         double ans = sphere.perimeter();
         if(ans != 18.85)
             System.out.println("testCirclePerimeter failed: wrong value calculated");
    }

    public static void testCircleDistanceFromOrigin(){
         Circle sphere = new Circle(0, 0, 3);
         double ans = sphere.distanceFromOrigin();
         if(ans != 0)
             System.out.println("testCircleDistanceFromOrigin failed: wrong value calculated");
    }

    public static void testCircleInBounds(){
         Circle sphere = new Circle(0,0,3);
         boolean ans = sphere.inBounds(4,6);
         if(ans != FALSE)
             System.out.println("testCircleInBounds failed: wrong calculated value");
    }

    public static void main(String[] args){
        testPointFunction1();
        testPointFunction2();
        testPointFunction3();
        testPointDistance();
        testPointDistanceFromOrigin();

        testRectangleFunction1();
        testRectangleFunction2();
        testRectangleFunction3();
        testRectangleArea();
        testRectanglePerimeter();
        testRectangleDistanceFromOrigin();
        testRectangleInBounds();

        testCircleFunction1();
        testCircleFunction2();
        testCircleArea();
        testCirclePerimeter();
        testCircleDistanceFromOrigin();
        testCircleInBounds();
    }
}
