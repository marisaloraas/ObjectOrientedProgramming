/**
 * Circle functions, building a circle based of a center and a radius,
 * finding the area, perimeter, distance from origin, and if
 * points are in the bounds of the circle
 *
 * @author Marisa Loraas
 * @version HW 1, #1
 * @bugs None
 */

package oop.mloraas.hw1.one;
import static java.lang.Boolean.*;

public class Circle {
    private double centerX;
    private double centerY;
    private double radius;

    //default circle
    public Circle(){
        this.centerX = 0.0;
        this.centerY = 0.0;
        this.radius = 1.0;
    }

    //makes circle
    public Circle(double x, double y, double rad){
        this.centerX = x;
        this.centerY = y;
        this.radius = rad;
    }

    public double getCenterX() {
        return centerX;
    }

    public double getCenterY() {
        return centerY;
    }

    public double getRadius() {
        return radius;
    }

    public void setCenterX(double centerX) {
        this.centerX = centerX;
    }

    public void setCenterY(double centerY) {
        this.centerY = centerY;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    //finds area of circle
    public double area(){
        double a = Math.pow(this.radius, 2);
        return a * Math.PI;
    }

    //finds perimeter of circle
    public double perimeter(){
        return 2 * this.radius * Math.PI;
    }

    //finds the distance from the origin of a circle
    public double distanceFromOrigin(){
        double ans = Math.pow(this.centerX, 2) + Math.pow(this.centerY, 2);
        return Math.sqrt(ans);
    }

    //finds if a point is within the bounds of a circle
    public boolean inBounds(double x, double y){
        boolean ans = FALSE;
        double test = Math.pow(x - this.centerX, 2) + Math.pow(y - this.centerY, 2);
        if(test < Math.pow(this.radius, 2))
            ans = TRUE;
        return ans;
    }
}
