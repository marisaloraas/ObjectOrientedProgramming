/**
 * Creates a point and can calculate its distance
 * from another point or from the origin
 *
 * @author Marisa Loraas
 * @version HW 1, #1
 * @bugs None
 */

package oop.mloraas.hw1.one;

import java.lang.Math.*;

import static java.lang.Math.pow;

public class Point{
    private double x;
    private double y;

    //returns x coordinate
    public double getX(){
        return x;
    }

    //returns y coordinate
    public double getY(){
        return y;
    }
    //sets x coordinate
    public void setX(double x) {
        this.x = x;
    }
    //sets y coordinate
    public void setY(double y) {
        this.y = y;
    }

    // A default constructor, to create the point (0, 0)
    public Point() {
        this.x = 0;
        this.y = 0;
    }

    // A constructor to explicitly assign both attributes of the class
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    //Passes in value to point
    public Point(Point var){
        this.x = var.x;
        this.y = var.y;
    }

    //gets distance of two points
    public double distance(Point var2){
        double distance1 = x - var2.x;
        double distance2 = y - var2.y;
        double answer = pow(distance1, 2.0) + pow(distance2, 2.0);
        return Math.sqrt(answer);
    }

    //gets distance from point and origin (0,0)
    public double distanceFromOrigin(){
        Point zero = new Point();
        return distance(zero);
    }
}