/**
 * Rectangle functions, builiding the points of a rectangle,
 * finding the area, perimeter, distance from origin, and if
 * points are in the bounds of the rectangle
 *
 * @author Marisa Loraas
 * @version HW 1, #1
 * @bugs None
 */

package oop.mloraas.hw1.one;

import static java.lang.Boolean.*;

public class Rectangle {
    private double lowerLeftX;
    private double lowerleftY;
    private double upperRightX;
    private double upperRightY;

    //these functions are pretty self explanitory
    public double getLowerLeftX() {
        return lowerLeftX;
    }

    public double getLowerLeftY() {
        return lowerleftY;
    }

    public double getUpperRightX() {
        return upperRightX;
    }

    public double getUpperRightY() {
        return upperRightY;
    }

    public void setLowerLeftX(double lowerLeftX) {
        this.lowerLeftX = lowerLeftX;
    }

    public void setLowerLeftY(double lowerleftY) {
        this.lowerleftY = lowerleftY;
    }

    public void setUpperRightX(double upperRightX) {
        this.upperRightX = upperRightX;
    }

    public void setUpperRightY(double upperRightY) {
        this.upperRightY = upperRightY;
    }

    //default settings of rectangle
    public Rectangle(){
        lowerLeftX = 0.0;
        lowerleftY = 0.0;
        upperRightX = 1.0;
        upperRightY = 1.0;
    }

    //changes width and height of rectangle
    public Rectangle(double height, double width){
        new Rectangle();
        this.upperRightX = width;
        this.upperRightY = height;
    }

    //changes all points of the rectangle
    public Rectangle(double x1, double x2, double y1, double y2){
        double tmp;

        if(x1 > x2){
            tmp = x1;
            x1 = x2;
            x2 = tmp;
        }
        if(y1 > y2){
            tmp = y1;
            y1 = y2;
            y2 = tmp;
        }

        this.lowerLeftX = x1;
        this.lowerleftY = y1;
        this.upperRightX = x2;
        this.upperRightY = y2;
    }

    //finds area of rectangle
    public double area(){
        double ansX = this.upperRightX - this.lowerLeftX;
        double ansY = this.upperRightY - this.lowerleftY;
        return ansX * ansY;
    }

    //finds perimeter of rectangle
    public double perimeter(){
        double ansX = 2 * (this.upperRightX - this.lowerLeftX);
        double ansY = 2 * (this.upperRightY - this.lowerleftY);
        return ansX + ansY;
    }

    //finds the distance of the points from the origin (0,0)
    public double distanceFromOrigin(){
        double ansX = this.lowerLeftX * this.upperRightX;
        double ansY = this.lowerleftY * this.upperRightY;
        return Math.sqrt(ansX + ansY);
    }

    //determines whether or not a point is within the bounds of a rectangle
    public boolean inBounds(double x, double y){
        boolean ans = TRUE;
        if(this.lowerleftY > y || this.upperRightY < y)
            ans = FALSE;
        if(this.lowerLeftX > x || this.upperRightX < x)
            ans = FALSE;
        return ans;
    }
}
