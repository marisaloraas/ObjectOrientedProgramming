/**
 * Formats a website citation for a bibliography
 *
 * @author Marisa Loraas
 * @version HW 3, #2
 * @bugs None
 */
package oop.mloraas.hw3.two;

import java.util.Arrays;

public class Website extends Citation{
    private String url;
    private String month;
    private int day;

    public String getUrl() {
        return url;
    }

    public String getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    /**
     * sets all things needed to site a website for a bibliography
     * @param url URL of website
     * @param month Month accessed
     * @param day day accessed
     * @param author author of website article
     * @param title title of website article
     * @param year year accessed
     */
    public Website(String url, String month, int day, String author, String title, int year){
        super(author, title, year);
        this.url = url;
        this.month = month;
        this.day = day;
    }

    /**
     * formats citation for website for a bibliography
     * @return citation
     */
    public String toString(){
        return Arrays.toString(author) + ", " + title + "., " + "\n" + url + ", " + month + " " + day;
    }

}
