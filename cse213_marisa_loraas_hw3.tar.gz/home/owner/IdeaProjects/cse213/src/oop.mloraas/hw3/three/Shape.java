/**
 * abstract class that apply's to circle and rectangle
 *
 * @author Marisa Loraas
 * @version hw3, #3
 * @bugs none
 */
package oop.mloraas.hw3.three;

public abstract class Shape {

    public abstract double width();
    public abstract double height();
    public abstract double area();
    public abstract double perimeter();
    public abstract boolean inBounds(Point p);
}
