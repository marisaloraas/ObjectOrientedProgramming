/**
 * Formats a general citation for a bibliography
 *
 * @author Marisa Loraas
 * @version HW 3, #2
 * @bugs None
 */
package oop.mloraas.hw3.two;

import java.util.Arrays;

public class Citation {
    protected Author[] author;
    protected String title;
    protected int year;

    public Author[] getAuthor() {
        return author.clone();
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    /**
     * Default sets author, title, and year of a citation
     * @param author author of citation
     * @param title title of citation
     * @param year year of citation
     */
    public Citation(String author, String title, int year){
        this.author = Author.splitAuthors(author);
        this.title = title;
        this.year = year;
    }

    /**
     * Properly formats a citation for a bibliography
     * @return citation
     */
    public String toString() {
        return Arrays.toString(author)  + ", " + title + " , " + year;
    }
}
