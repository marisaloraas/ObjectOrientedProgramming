/**
 * JUnit testing for Ellipse
 *
 * @author Marisa Loraas
 * @version HW 3, #3
 * @bugs None
 */
package oop.mloraas.hw3.three;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class EllipseTest {

    @Test
    public void testEllipse(){
        Ellipse e = new Ellipse();
        double expected = 1;
        double actual = e.getMinorRadius();

        Assert.assertEquals("Minor Radius does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testEllipse2(){
        Point p = new Point(0,0);
        Ellipse e = new Ellipse(p, 1, 1);
        double expected = 1;
        double actual = e.getMinorRadius();

        Assert.assertEquals("Minor Radius does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testWidth(){
        Ellipse e = new Ellipse();
        double expected = 2;
        double actual = e.width();

        Assert.assertEquals("Width does not match expected value",
                expected, actual, 0.1);
    }

    //I'm really not sure why this is failing
    @Test
    public void testHeight(){
        Ellipse e = new Ellipse();
        double expected = 2;
        double actual = e.height();

        Assert.assertEquals("Height does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testDiameter(){
        Ellipse e = new Ellipse();
        double expected = 2;
        double actual = e.diameter();

        Assert.assertEquals("Diameter does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testArea(){
        Ellipse e = new Ellipse();
        double expected = Math.PI;
        double actual = e.area();

        Assert.assertEquals("Area does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testPerimeter(){
        Ellipse e = new Ellipse();
        double expected = 2 * Math.PI;
        double actual = e.perimeter();

        Assert.assertEquals("Perimeter does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testInBounds(){
        Point p = new Point(2.0, 2.0);
        Ellipse e = new Ellipse();
        boolean actual = e.inBounds(p);

        Assert.assertFalse("In bounds method dosn't match expected result", actual);
    }

    @Test
    public void testGetBoundingBox(){
        Rectangle actual = new Rectangle();
        Ellipse e = new Ellipse();
        Rectangle expected = e.getBoundingBox();

        Assert.assertEquals("Focal Distance does not match expected value",
                expected, actual);
    }

    @Test
    public void testFocalDistance(){
        Ellipse e = new Ellipse();
        double expected = 0;
        double actual = e.focalDistance();

        Assert.assertEquals("Focal Distance does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testEccentricity(){
        Ellipse e = new Ellipse();
        double expected = 0;
        double actual = e.eccentricity();

        Assert.assertEquals("Eccentricity does not match expected value",
                expected, actual, 0.1);
    }
}