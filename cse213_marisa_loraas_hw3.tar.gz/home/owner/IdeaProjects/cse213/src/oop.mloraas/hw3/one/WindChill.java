/**
 * Finds the windchill and chance of frostbite for a given temperature and
 * wind speed
 *
 * @author Marisa Loraas
 * @version HW 3, #1
 * @bugs None
 */
package oop.mloraas.hw3.one;

import java.util.Scanner;

public class WindChill {

    /**
     * Finds wind chill
     * @param temp temperature
     * @param v speed of wind
     * @return wind chill temperature
     */
    public static Fahrenheit windChill(Temperature temp, double v) {
        return new Fahrenheit(35.74 + temp.getFahrenheit() *
                0.6215 - 35.3225 * Math.pow(v, 0.16));
    }

    /**
     * finds the skin Temperature
     * @param temp temperature
     * @param v speed of wind
     * @return wind chill temperature
     */
    public static Celsius skinTemperature(Temperature temp, double v){
        return new Celsius(0.1 * temp.getCelsius() - 2.7883 * Math.log(v) + 0.2977 *
                temp.getCelsius() * Math.pow(v, 0.16));
    }

    /**
     * Tells if you'll get frost bite or not
     * @param temp temperature
     * @param v speed of wind
     */
    public static void frostbiteWarning(Temperature temp, double v){
        if(skinTemperature(temp,v).getCelsius() > -4.8)
            System.out.println("No Danger");
        else if(temp.getCelsius() > -10 && v < 15)
            System.out.println("No Danger");
        else if (temp.getCelsius() < -45 && v > 150)
            System.out.println("Extreme Danger!");
        else if (temp.getCelsius() <= 7.5 * Math.log(v) - 51.4)
            System.out.println("Warning");
        else
            System.out.println("Extreme Danger!");

    }
    public static void main(String[] args){
        double x = 0;
        String tunit;
        double speed;
        double answer;
        Temperature temp = new Temperature(x);
        Scanner in = new Scanner(System.in);

        System.out.println("Wind Chill/Frostbite Calculator");
        System.out.println("=============================== \n");

        System.out.print("Enter the temperature> ");
        x = in.nextDouble();
        in.nextLine();

        System.out.print("Enter the Temperature unit [K/C/F]> ");
        tunit = in.nextLine();

        switch (tunit) {
            case "K":
                temp = new Kelvin(x);
                break;
            case "C":
                temp = new Celsius(x);
                break;
            case "F":
                temp = new Fahrenheit(x);
                break;
        }


        System.out.print("Enter the wind speed (mph)> ");
        speed = in.nextDouble();
        System.out.println("");

        answer = WindChill.windChill(temp, speed).getFahrenheit();
        System.out.println("Wind Chill Temperature: " + answer + " Degrees Fahrenheit");

        answer = WindChill.skinTemperature(temp, speed).getCelsius();
        System.out.println("Final Skin Temperature: " + answer + " Degrees Celsius");

        WindChill.frostbiteWarning(temp, speed);
    }
}
