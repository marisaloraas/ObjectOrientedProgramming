/**
 * Formats bibliography citation for Book
 *
 * @author Marisa Loraas
 * @version HW 3, #2
 * @bugs None
 */
package oop.mloraas.hw3.two;

import java.util.Arrays;

public class Book extends Citation {
    protected String publisher;

    public String getPublisher() {
        return publisher;
    }

    /**
     * default sets the author, title, year, and publisher of a book
     * @param author author of book
     * @param title title of book
     * @param year year book was released
     * @param publisher publisher of book
     */
    public Book(String author, String title, int year, String publisher){
        super(author, title, year);
        this.publisher = publisher;
    }

    /**
     * Converts book information into proper citation form (string)
     * @return citation
     */
    public String toString() {
        return Arrays.toString(author) + ", " + title + "., " + year + "\n" + publisher;
    }
}
