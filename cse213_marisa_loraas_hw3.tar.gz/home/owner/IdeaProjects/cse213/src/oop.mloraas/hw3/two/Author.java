/**
 * Sets the author for bibliography citations
 *
 * @author Marisa Loraas
 * @version HW 3, #2
 * @bugs None
 */

package oop.mloraas.hw3.two;

public class Author {
    private String lastName;
    private String firstName;
    private String middleInitial;

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    /**
     * Sets the Auhors name
     * @param fn first name
     * @param ln last name
     * @param mi middle Initial
     */
    public Author(String fn, String ln, String mi){
        this.firstName = fn;
        this.lastName = ln;
        this.middleInitial = mi;
    }

    /**
     * Splits up a string to Set authors name
     * @param full authors full name
     */
    public Author(String full){
        String[] split = full.strip().split(" ");
        if(split.length == 3){
            this.firstName = split[0];
            this.middleInitial = split[1].charAt(0) + ".";
            this.lastName = split[2];
        }else if(split.length == 2){
            this.firstName = split[0];
            this.middleInitial = "";
            this.lastName = split[1];
        }
    }

    /**
     * gets the citation format for an author in a bibilography (i replaced this with get citation)
     * @return citation
     */
    public String toString(){
        return this.lastName + ", " + this.firstName.charAt(0) + ". " + this.middleInitial;
    }

    /**
     * Splits up several authors into an author array
     * @param author strings of authors
     * @return array of split authors
     */
    public static Author[] splitAuthors(String author){
        author = author.replaceAll("and", "");
        String list[] = author.split(",");
        Author[] authors = new Author[list.length];
        for(int i = 0; i < authors.length; i++)
            authors[i] = new Author(list[i].trim());

        return authors;
    }

}
