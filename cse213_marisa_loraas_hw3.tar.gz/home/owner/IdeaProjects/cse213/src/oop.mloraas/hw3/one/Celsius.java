/**
 * Temperature subclass Celsius
 *
 * @author Marisa Loraas
 * @version HW 3, #1
 * @bugs None
 */
package oop.mloraas.hw3.one;

public class Celsius extends Temperature{

    Celsius(double temperature){
        super(temperature);
    }

    public double getKelvin() {
        return this.degrees + 273.15;
    }

    public double getFahrenheit() {
        return this.degrees * 1.8 + 32.0;
    }

    public String toString() {
        return super.toString() + " Degrees Celsius";
    }
}
