/**
 * Formats a book citation with chapter and pages included for a bibliography
 *
 * @author Marisa Loraas
 * @version HW 3, #2
 * @bugs None
 */
package oop.mloraas.hw3.two;

import java.util.Arrays;

public class Chapter extends Book{
    private String chapterName;
    private int chapterNumber;
    private int startPage;
    private int endPage;

    public String getChapterName() {
        return chapterName;
    }

    public int getChapterNumber() {
        return chapterNumber;
    }

    public int getStartPage() {
        return startPage;
    }

    public int getEndPage() {
        return endPage;
    }

    /**
     * Default sets all information for a book citation with a specific chapter and pages
     * @param chapterName Name of Chapter
     * @param chapterNumber Number of Chapter
     * @param startPage Page where chapter Starts
     * @param endPage Page where Chapter Ends
     * @param author Author of Book
     * @param title Title of Book
     * @param year year book was released
     * @param publisher Publisher of book
     */
    public Chapter(String chapterName, int chapterNumber, int startPage, int endPage, String author, String title,
                   int year, String publisher){
        super(author, title, year, publisher);
        this.chapterName = chapterName;
        this.chapterNumber = chapterNumber;
        this.startPage = startPage;
        this.endPage = endPage;
    }

    /**
     * converts this type of book citation in proper format
     * @return citation
     */
    public String toString(){
        return Arrays.toString(author) + ", " + title + "., " + year + "\n" + "Chapter " + chapterNumber + ", "
                + chapterName + " (pp " + startPage + "-" + endPage + ")";
    }
}
