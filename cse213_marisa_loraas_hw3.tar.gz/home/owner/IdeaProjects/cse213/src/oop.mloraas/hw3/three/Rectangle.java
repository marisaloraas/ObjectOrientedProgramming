/**
 * Rectangle function from hw1 and hw2
 * but rectangle is confined by two points
 * and extends to shape
 *
 * @author Marisa Loraas
 * @version HW 3, #3
 * @bugs None
 */

package oop.mloraas.hw3.three;

public class Rectangle extends Shape{

    private Point lowerLeft;
    private Point upperRight;

    public Point getLowerLeft() {
        return lowerLeft;
    }

    public Point getUpperRight() {
        return upperRight;
    }

    /**
     * Creates default rectangle at origin for lower left corner
     * and (1,1) for upper right corner
     */
    public Rectangle(){
        this.lowerLeft = new Point();
        this.upperRight = new Point(1,1);
    }

    /**
     * Makes rectangle with specific input for points
     * @param one lower left corner
     * @param two upper right corner
     */
    public Rectangle(Point one, Point two){
        if(one.getY() > two.getY()){
            double temp = one.getY();
            one.setY(two.getY());
            two.setY(temp);
        }
        if(one.compareTo(two) > 0){
            Point temp = one;
            one = two;
            two = temp;
        }
        this.lowerLeft = one;
        this.upperRight = two;
    }

    /**
     * Makes rectangle with specific input for width and height
     * @param w width
     * @param h height
     */
    public Rectangle(double w, double h){
        this.lowerLeft = new Point();
        this.upperRight = new Point(w, h);
    }

    /**
     * Gets the lower right point of the rectangle
     * @return Lower right Point
     */
    public Point getLowerRight(){
        return new Point(this.upperRight.getX(), this.lowerLeft.getY());
    }

    /**
     * Gets the upper left point of the rectangle
     * @return upper left point
     */
    public Point getUpperLeft(){
        return new Point(this.lowerLeft.getX(), this.upperRight.getY());
    }

    /**
     * Finds area of rectangle
     * @return area of rectangle
     */
    public double area(){
        return (this.upperRight.getX() - this.lowerLeft.getX()) *
                (this.upperRight.getY() - this.lowerLeft.getY());
    }

    /**
     * Finds perimeter of rectangle
     * @return perimeter of rectangle
     */
    public double perimeter(){
        return 2 * ((this.upperRight.getX() - this.lowerLeft.getX()) +
                (this.upperRight.getY() - this.lowerLeft.getY()));
    }

    /**
     * Finds if a point is in the bounds of a rectangle
     * @param point point on graph
     * @return true if in bounds, false otherwise
     */
    public boolean inBounds(Point point){
        return (this.lowerLeft.compareTo(point) < 0) &&
                (this.upperRight.compareTo(point) > 0);
    }

    /**
     * gets width of rectangle
     * @return width
     */
    public double width(){
        return this.upperRight.getX() - this.lowerLeft.getX();
    }

    /**
     * return height of rectangle
     * @return height
     */
    public double height(){
        return this.upperRight.getY() - this.lowerLeft.getY();
    }
}
