/**
 * JUnit testing for Parallelogram
 *
 * @author Marisa Loraas
 * @version HW 3, #3
 * @bugs None
 */
package oop.mloraas.hw3.three;

import org.junit.Assert;
import org.junit.Test;

import static java.lang.Boolean.TRUE;
import static org.junit.Assert.*;

public class ParallelogramTest {
    @Test
    public void testParallelogram(){
        Parallelogram p = new Parallelogram();
        double expectedAngle = Math.PI/2;
        double actualAngle = p.getSkewAngle();

        Assert.assertEquals("Skew Angle does not match expected value",
                expectedAngle, actualAngle, 0.1);
    }

    @Test
    public void testParallelogram2(){
        Point p1 = new Point(0.0, 0.0);
        Point p2 = new Point(1.0, 1.0);
        Parallelogram para = new Parallelogram(p1, p2, 1.4);

        double expectedAngle = 1.4;
        double actualAngle = para.getSkewAngle();

        Assert.assertEquals("Skew Angle does not match expected value",
                expectedAngle, actualAngle, 0.1);
    }

    @Test
    public void testBaseLength(){
        Parallelogram para = new Parallelogram();
        double expected = 1 / Math.tan(Math.PI / 2);
        double actual = para.baseLength();

        Assert.assertEquals("Base Length does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testGetLowerRight(){
        Parallelogram para = new Parallelogram();
        double expected = 1 - (1 / Math.tan(Math.PI / 2));
        double actual = para.getLowerRight().getX();

        Assert.assertEquals("Lower Right x coordinate does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testGetUpperLeft(){
        Parallelogram para = new Parallelogram();
        double expected = 0 + (1 / Math.tan(Math.PI / 2));
        double actual = para.getUpperLeft().getX();

        Assert.assertEquals("Upper Left x coordinate does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testWidth(){
        Parallelogram para = new Parallelogram();
        double expected = 1;
        double actual = para.width();
        Assert.assertEquals("Width does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testArea(){
        Parallelogram para = new Parallelogram();
        double expected = 1;
        double actual = para.area();

        Assert.assertEquals("Area does not match expected value",
                expected, actual, 0.1);
    }

    @Test
    public void testPerimeter(){
        Parallelogram para = new Parallelogram();
        double expected = 4;
        double actaul = para.perimeter();

        Assert.assertEquals("Perimeter dosn't match expected",
                expected, actaul, 0.1);
    }

    @Test
    public void testInBounds(){
        Parallelogram para = new Parallelogram();
        Point p = new Point (0.5, 0.5);
        boolean actual = para.inBounds(p);

        Assert.assertTrue("In bounds dosnt match expected result",actual);
    }
}