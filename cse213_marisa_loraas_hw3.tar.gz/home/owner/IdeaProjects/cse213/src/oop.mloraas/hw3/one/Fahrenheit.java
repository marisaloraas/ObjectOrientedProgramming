/**
 * Temperature subclass Fahrenheit
 *
 * @author Marisa Loraas
 * @version HW 3, #1
 * @bugs None
 */
package oop.mloraas.hw3.one;

public class Fahrenheit extends Temperature{

    public Fahrenheit(double degrees) {
        super(degrees);
    }

    public double getKelvin() {
        return getCelsius() + 273.15;
    }

    public double getCelsius() {
        return (this.degrees - 32.0) / 1.8;
    }

    public String toString() {
        return super.toString() + " Degrees Fahrenheit";
    }
}
