/**
 * Temperature functions with celsius, kelvin, and fahrenheit
 *
 * @author Marisa Loraas
 * @version HW 3, #1
 * @bugs None
 */
package oop.mloraas.hw3.one;

public class Temperature {
    protected double degrees;

    public Temperature(double degrees) {
        this.degrees = degrees;
    }

    public double getDegrees() {
        return degrees;
    }

    public void setDegrees(double degrees) {
        this.degrees = degrees;
    }

    public double getKelvin(){
        return degrees;
    }

    public double getCelsius(){
        return degrees;
    }

    public double getFahrenheit(){
        return degrees;
    }

    public String toString() {
        return "Temperature{" + "degrees=" + degrees + "}";
    }
}


