/**
 * Formats a newspaper citation for a bibliography
 *
 * @author Marisa Loraas
 * @version HW 3, #2
 * @bugs None
 */
package oop.mloraas.hw3.two;

import javax.lang.model.element.NestingKind;
import java.util.Arrays;

public class Newspaper extends  Citation{
    private String newspaper;
    private String month;
    private int day;

    public String getNewspaper() {
        return newspaper;
    }

    public String getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    /**
     * All information needed to site a Newspaper
     * @param newspaper Newspaper Name
     * @param month Month Released
     * @param day Day Released
     * @param author Author of Article
     * @param title Title of Article
     * @param year Year released
     */
    public Newspaper(String newspaper, String month, int day, String author, String title , int year){
        super(author, title, year);
        this.newspaper = newspaper;
        this.month = month;
        this.day = day;
    }

    /**
     * Formats newspaper citation for a bibliography
     * @return citation
     */
    public String toString(){
        return Arrays.toString(author) + ", " + title + ", " + year + "\n" + newspaper + ", " + month + " " + day;
    }

}
