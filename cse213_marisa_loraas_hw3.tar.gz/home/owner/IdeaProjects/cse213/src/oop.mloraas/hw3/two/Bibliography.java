/**
 * Makes a bibliography for each type of citation
 *
 * @author Marisa Loraas
 * @version HW 3, #2
 * @bugs brackets around authors
 */
package oop.mloraas.hw3.two;
public class Bibliography {
    public static void main(String[] args){
        Citation[] bib = new Citation[5];
        int i;

        bib[0] = new Book("Henry David Thoreau", "Walden", 1854,
                "Ticknor and Fields Publishing Co.");

        bib[1] = new Chapter("A Short Cut to Mushrooms", 4, 58, 65,
                "J. R. Martin", "The Fellowship of the Ring", 1954, "");

        bib[2] = new Journal("Mind", 59, 433, 460, "Alan M. Turing,",
                "Computing Machinery and Intelligence", 1950);

        bib[3] = new Newspaper("New York Times", "August", 8, "John Herbers",
                "NIXON RESIGNS", 1974);

        bib[4] = new Website("http://www.stephendiehl.com/posts/abstraction.html", "January", 9,
                "Somthing Diehl", "Functional Programming, Abstraction, and Naming Things", 0);

        for(i = 0; i < 5; i++){
            System.out.println(bib[i].toString());
            System.out.println();
        }
    }
}
