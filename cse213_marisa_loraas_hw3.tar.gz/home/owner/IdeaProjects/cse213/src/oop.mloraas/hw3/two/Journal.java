/**
 * Formats Journal citaiton for a bibliography
 *
 * @author Marisa Loraas
 * @version HW 3, #2
 * @bugs None
 */
package oop.mloraas.hw3.two;

import java.util.Arrays;

public class Journal extends Citation{
    private String journalName;
    private int volume;
    private int startPage;
    private int endPage;

    public String getJournalName() {
        return journalName;
    }

    public int getVolume() {
        return volume;
    }

    public int getStartPage() {
        return startPage;
    }

    public int getEndPage() {
        return endPage;
    }

    /**
     * Sets all information for the citation for a Journal
     * @param journalName Name of journal
     * @param volume Volume number
     * @param startPage page where citation starts
     * @param endPage page where citation ends
     * @param author Author of publication
     * @param title Title of publication
     * @param year year of release
     */
    public Journal(String journalName, int volume, int startPage, int endPage, String author, String title, int year){
        super(author, title, year);
        this.journalName = journalName;
        this.volume = volume;
        this.startPage = startPage;
        this.endPage = endPage;
    }

    /**
     * properly formats journal citation for a bibliography
     * @return citation
     */
    public String toString(){
        return Arrays.toString(author) + ", " + title + ", " + year + "\n" + journalName + ", vol. " + volume + " (pp. "
                + startPage + "-" + endPage + ")";
    }
}
