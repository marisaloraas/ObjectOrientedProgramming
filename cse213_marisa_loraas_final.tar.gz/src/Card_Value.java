/**
 * Uno card value enumeration clasee
 *
 * @author Marisa Loraas
 * @version Final Project
 * @bugs None
 */


public enum Card_Value {
    ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, SKIP, REVERSE, DRAW_TWO,
    WILD, WILD_FOUR;

    public static Card_Value value(int i){
        if(i == 0)
            return ZERO;
        else if(i == 1)
            return ONE;
        else if(i == 2)
            return TWO;
        else if(i == 3)
            return THREE;
        else if(i == 4)
            return FOUR;
        else if(i == 5)
            return FIVE;
        else if(i == 6)
            return SIX;
        else if(i == 7)
            return SEVEN;
        else if(i == 8)
            return EIGHT;
        else if(i == 9)
            return NINE;
        else if(i == 10)
            return SKIP;
        else if(i == 11)
            return REVERSE;
        else if(i == 12)
            return DRAW_TWO;
        else
            return null;

    }

    @Override
    public String toString() {
        switch (this){
            case ZERO:
                return "ZERO";
            case ONE:
                return "ONE";
            case TWO:
                return "TWO";
                case THREE:
                return "THREE";
            case FOUR:
                return "FOUR";
            case FIVE:
                return "FIVE";
            case SIX:
                return "SIX";
            case SEVEN:
                return "SEVEN";
            case EIGHT:
                return "EIGHT";
                case NINE:
                return "NINE";
            case SKIP:
                return "SKIP";
            case REVERSE:
                return "REVERSE";
            case DRAW_TWO:
                return "+2";
                case WILD:
                return "WILD";
                case WILD_FOUR:
                return "WILD +4";
            default:
                return " ";
        }
    }
}
