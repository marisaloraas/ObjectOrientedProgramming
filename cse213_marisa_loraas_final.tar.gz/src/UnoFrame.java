/**
 * Builds entire uno frame and includes AI moves
 *
 * @author Marisa Loraas
 * @version Final Project
 * @bugs None
 */



import javax.swing.*;
import java.util.ArrayList;

public class UnoFrame extends javax.swing.JFrame {

    private ArrayList<JButton> card_buttons = new ArrayList<JButton>();
    private Uno uno_game = new Uno();
    private int index;
    /**
     * Creates new form UnoFrame
     */
    public UnoFrame() {
        initComponents();
                card_buttons.add(card1);
                card_buttons.add(card2);
                card_buttons.add(card3);
                card_buttons.add(card4);
                card_buttons.add(card5);
                card_buttons.add(card6);
                card_buttons.add(card7);
                card_buttons.add(card8);
                card_buttons.add(card9);
                card_buttons.add(card10);
                card_buttons.add(card11);
                card_buttons.add(card12);
                card_buttons.add(card13);
                card_buttons.add(card14);

                uno_game = new Uno();
                uno_game.setUf(this);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }

                labelScores(0, 0, 0, 0);
    }

    public void setIndex(int i){
        index = i;
    }

    public void getAIMove(ArrayList<Card> ai){
        Card getBackground;
        boolean pull = true;
        while(pull) {
            for (int i = 0; i < ai.size(); i++) {
                getBackground = ai.get(i);
                uno_game.playCard(ai.get(i), ai);
                if (uno_game.isValidCard()) {
                    if (getBackground.getValue() == Card_Value.WILD_FOUR) {
                        uno_game.getDiscard().remove(getBackground);
                        uno_game.getDiscard().add(new Card(Card_Color.BLUE, Card_Value.WILD_FOUR));
                    } else if (getBackground.getValue() == Card_Value.WILD) {
                        uno_game.getDiscard().remove(getBackground);
                        uno_game.getDiscard().add(new Card(Card_Color.BLUE, Card_Value.WILD));
                    }
                    jButton3.setBackground(uno_game.getDiscard().get(uno_game.topCard()).getColor().get_Color());
                    jButton3.setText(getBackground.getValue().toString());
                    break;
                }
            }

            if (!uno_game.isValidCard()) {
                ai.add(uno_game.getDeck().getCard());
            }else
                pull = false;
        }
    }


    public void playGame() {
        while (index != 0) {
            if (uno_game.getDeck().getDeck().size() == 0) {
                Card move;
                for (int i = 0; i < uno_game.getDiscard().size() - 2; i++) {
                    uno_game.getDeck().getDeck().add(uno_game.getDiscard().get(i));
                    move = uno_game.getDiscard().get(i);
                    uno_game.getDiscard().remove(move);
                }
                uno_game.getDeck().shuffle();
            }
            if (uno_game.getOrder()) {
                if (index >= 4)
                    index = 0;
                chooseTurn(index);
                index++;
                if (uno_game.skip)
                    index++;
            } else {
                if (index <= -1)
                    index = 3;
                chooseTurn(index);
                index--;
                if (uno_game.skip)
                    index--;
            }


        }
        jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
        jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
        for (int i = 0; i < uno_game.getPlayer().size(); i++) {
            card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
            card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());
        }
        for(int j = uno_game.getPlayer().size(); j < card_buttons.size(); j++){
            card_buttons.get(j).setBackground(null);
            card_buttons.get(j).setText(null);
        }
    }

    public void chooseTurn(int i){
       if(uno_game.indexPlayingOrder(i) == uno_game.getAi1()){
            getAIMove(uno_game.getAi1());
        }else if(uno_game.indexPlayingOrder(i) == uno_game.getAi2()){
            getAIMove(uno_game.getAi2());
        }else if(uno_game.indexPlayingOrder(i) == uno_game.getAi3()){
            getAIMove(uno_game.getAi3());
        }
    }

    public void labelScores(int player_score, int ai1_score, int ai2_score, int ai3_score){
        playerScore.setText("Player Score: " + player_score);
        ai1Score.setText("AI 1 Score: " + ai1_score);
        ai2Score.setText("AI 2 Score: " + ai2_score);
        ai3Score.setText("AI 3 Score: " + ai3_score);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        drawButton = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        card8 = new javax.swing.JButton();
        card2 = new javax.swing.JButton();
        card3 = new javax.swing.JButton();
        card4 = new javax.swing.JButton();
        card5 = new javax.swing.JButton();
        card6 = new javax.swing.JButton();
        card7 = new javax.swing.JButton();
        card1 = new javax.swing.JButton();
        card9 = new javax.swing.JButton();
        card10 = new javax.swing.JButton();
        card11 = new javax.swing.JButton();
        card12 = new javax.swing.JButton();
        card13 = new javax.swing.JButton();
        card14 = new javax.swing.JButton();
        UNO = new javax.swing.JLabel();
        playerScore = new javax.swing.JLabel();
        ai1Score = new javax.swing.JLabel();
        ai2Score = new javax.swing.JLabel();
        ai3Score = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Deck");

        drawButton.setBackground(java.awt.Color.lightGray);
        drawButton.setText("Draw");
        drawButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drawButtonActionPerformed(evt);
            }
        });

        jButton3.setText("Discard");

        card8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card8ActionPerformed(evt);
            }
        });

        card2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card2ActionPerformed(evt);
            }
        });

        card3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card3ActionPerformed(evt);
            }
        });

        card4.setText("Card 4");
        card4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card4ActionPerformed(evt);
            }
        });

        card5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card5ActionPerformed(evt);
            }
        });

        card6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card6ActionPerformed(evt);
            }
        });

        card7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card7ActionPerformed(evt);
            }
        });

        card1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card1ActionPerformed(evt);
            }
        });

        card9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card9ActionPerformed(evt);
            }
        });

        card10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card10ActionPerformed(evt);
            }
        });

        card11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card11ActionPerformed(evt);
            }
        });

        card12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card12ActionPerformed(evt);
            }
        });

        card13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card13ActionPerformed(evt);
            }
        });

        card14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                card14ActionPerformed(evt);
            }
        });

        UNO.setFont(new java.awt.Font("Ubuntu", 0, 48)); // NOI18N
        UNO.setText("UNO");

        playerScore.setText("jLabel2");

        ai1Score.setText("jLabel3");

        ai2Score.setText("jLabel4");

        ai3Score.setText("jLabel4");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(UNO)
                                                        .addComponent(playerScore, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                                                        .addComponent(ai1Score, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(ai2Score, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(ai3Score, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(68, 68, 68)
                                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(51, 51, 51)
                                                .addComponent(drawButton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(41, 41, 41))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(card8, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(card1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addComponent(card9, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card10, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card11, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card12, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card13, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(card14, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addComponent(card2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card6, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(card7, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(0, 0, Short.MAX_VALUE)))
                                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(34, 34, 34)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addGap(0, 0, Short.MAX_VALUE)
                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                .addComponent(drawButton)
                                                                                .addGap(87, 87, 87)))))
                                                .addGap(23, 23, 23))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(21, 21, 21)
                                                .addComponent(UNO)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(playerScore)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(ai1Score)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(ai2Score)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(ai3Score)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(card2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card4, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card5, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card6, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card7, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(card9, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card8, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card10, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card11, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card12, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card13, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(card14, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }//


    private void drawButtonActionPerformed(java.awt.event.ActionEvent evt) {
        if (uno_game.getDeck().getDeck().size() == 0) {
            Card move;
            for (int i = 0; i < uno_game.getDiscard().size() - 2; i++) {
                move = uno_game.getDiscard().get(i);
                if(move.getValue() == Card_Value.WILD) {
                    uno_game.getDeck().getDeck().add(new Card(Card_Value.WILD));
                }else if(move.getValue() == Card_Value.WILD_FOUR){
                    uno_game.getDeck().getDeck().add(new Card(Card_Value.WILD_FOUR));
                }else
                   uno_game.getDeck().getDeck().add(move);
                uno_game.getDiscard().remove(move);
            }
            uno_game.getDeck().shuffle();
        }

        uno_game.getPlayer().add(uno_game.getDeck().getCard());
        card_buttons.get(uno_game.getPlayer().size() - 1).setBackground(uno_game.getPlayer().get(uno_game.getPlayer().size() -1 ).getColor().get_Color());
        card_buttons.get(uno_game.getPlayer().size() - 1).setText(uno_game.getPlayer().get(uno_game.getPlayer().size() - 1).getValue().toString());
    }

    private void card6ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(5).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(5).getValue() == Card_Value.WILD)&&
        uno_game.getPlayer().get(5).getColor() == Card_Color.WHITE){
           WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(5));
           wild.setVisible(true);
           uno_game.getPlayer().set(5, wild.getNew_card());

        }else {
            uno_game.playCard(uno_game.getPlayer().get(5), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }

    }

    private void card2ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(1).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(1).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(1).getColor() == Card_Color.WHITE){
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(1));
            wild.setVisible(true);
             uno_game.getPlayer().set(1, wild.getNew_card());

        }else {
            uno_game.playCard(uno_game.getPlayer().get(1), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }



    private void card1ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(0).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(0).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(0).getColor() == Card_Color.WHITE){
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(0));
            wild.setVisible(true);
             uno_game.getPlayer().set(0, wild.getNew_card());
        }else {
            uno_game.playCard(uno_game.getPlayer().get(0), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }

    private void card3ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(2).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(2).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(2).getColor() == Card_Color.WHITE){
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(2));
            wild.setVisible(true);
            uno_game.getPlayer().set(2, wild.getNew_card());

        }else {
            uno_game.playCard(uno_game.getPlayer().get(2), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }

    private void card4ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(3).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(3).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(3).getColor() == Card_Color.WHITE){
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(3));
             wild.setVisible(true);
            uno_game.getPlayer().set(3, wild.getNew_card());

        }else {
            uno_game.playCard(uno_game.getPlayer().get(3), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }

    private void card5ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(4).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(4).getValue() == Card_Value.WILD)&&
        uno_game.getPlayer().get(4).getColor() == Card_Color.WHITE){
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(4));
            wild.setVisible(true);
            uno_game.getPlayer().set(4, wild.getNew_card());
        }else {
            uno_game.playCard(uno_game.getPlayer().get(4), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }

    private void card7ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(6).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(6).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(6).getColor() == Card_Color.WHITE){
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(6));
            wild.setVisible(true);
            uno_game.getPlayer().set(6, wild.getNew_card());    
        }else {
            uno_game.playCard(uno_game.getPlayer().get(6), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
            playGame();
            }
        }
    }

    private void card8ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(7).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(7).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(7).getColor() == Card_Color.WHITE){
            card_buttons.get(7).setBackground(uno_game.getPlayer().get(7).getColor().get_Color()); 
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(7));
                wild.setVisible(true);
            uno_game.getPlayer().set(7, wild.getNew_card());
        }else {
            uno_game.playCard(uno_game.getPlayer().get(7), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }

    private void card9ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(8).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(8).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(8).getColor() == Card_Color.WHITE){
            card_buttons.get(8).setBackground(uno_game.getPlayer().get(8).getColor().get_Color());
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(8));
                wild.setVisible(true);
            uno_game.getPlayer().set(8, wild.getNew_card());
        }else {
            uno_game.playCard(uno_game.getPlayer().get(8), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }

    }

    private void card10ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(9).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(9).getValue() == Card_Value.WILD) &&
                uno_game.getPlayer().get(9).getColor() == Card_Color.WHITE){
            card_buttons.get(9).setBackground(uno_game.getPlayer().get(9).getColor().get_Color());
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(9));
                wild.setVisible(true);
            uno_game.getPlayer().set(9, wild.getNew_card());
        }else {
            uno_game.playCard(uno_game.getPlayer().get(9), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }

    private void card11ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(10).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(10).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(10).getColor() == Card_Color.WHITE){
            card_buttons.get(10).setBackground(uno_game.getPlayer().get(10).getColor().get_Color());
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(10));
                wild.setVisible(true);
            uno_game.getPlayer().set(10, wild.getNew_card());

        }else {
            uno_game.playCard(uno_game.getPlayer().get(10), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

           /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }

    }

    private void card12ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(11).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(11).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(11).getColor() == Card_Color.WHITE){
            card_buttons.get(11).setBackground(uno_game.getPlayer().get(11).getColor().get_Color());
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(11));
                wild.setVisible(true);
            uno_game.getPlayer().set(11, wild.getNew_card());
        }else {
            uno_game.playCard(uno_game.getPlayer().get(11), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }

    private void card13ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(12).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(12).getValue() == Card_Value.WILD) &&
        uno_game.getPlayer().get(12).getColor() == Card_Color.WHITE){
            card_buttons.get(12).setBackground(uno_game.getPlayer().get(12).getColor().get_Color());
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(12));
            wild.setVisible(true);
            uno_game.getPlayer().set(12, wild.getNew_card());
        }else {
            uno_game.playCard(uno_game.getPlayer().get(12), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }

    private void card14ActionPerformed(java.awt.event.ActionEvent evt) {
        if((uno_game.getPlayer().get(13).getValue() == Card_Value.WILD_FOUR || uno_game.getPlayer().get(13).getValue() == Card_Value.WILD) &&
                uno_game.getPlayer().get(13).getColor() == Card_Color.WHITE){
            WildCards wild = new WildCards(uno_game, uno_game.getPlayer().get(13));
            wild.setVisible(true);
            uno_game.getPlayer().set(13, wild.getNew_card());
        }else {
            card_buttons.get(13).setBackground(uno_game.getPlayer().get(13).getColor().get_Color());

            uno_game.playCard(uno_game.getPlayer().get(13), uno_game.getPlayer());
            if (uno_game.isValidCard()) {
                if (uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                    new WildCards(uno_game, uno_game.getDiscard().get(uno_game.topCard())).setVisible(true);
                }
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getColor().get_Color());
                jButton3.setText(uno_game.getDiscard().get(uno_game.getDiscard().size() - 1).getValue().toString());
                for (int i = 0; i < uno_game.getPlayer().size(); i++) {
                    card_buttons.get(i).setBackground(uno_game.getPlayer().get(i).getColor().get_Color());
                    card_buttons.get(i).setText(uno_game.getPlayer().get(i).getValue().toString());

                }
                card_buttons.get(uno_game.getPlayer().size()).setText(null);
                card_buttons.get(uno_game.getPlayer().size()).setBackground(null);

                if (uno_game.getOrder()) {
                    index++;
                    if (index >= 4)
                        index = 0;
                    if (uno_game.skip)
                        index++;
                } else {
                    index--;
                    if (index <= -1)
                        index = 3;
                    if (uno_game.skip)
                        index--;
                }

            /*if(uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD || uno_game.getDiscard().get(uno_game.topCard()).getValue() == Card_Value.WILD_FOUR) {
                new WildCards(uno_game, this).setVisible(true);
                jButton3.setBackground(uno_game.getDiscard().get(uno_game.getDiscard().size() -1).getColor().get_Color());
            }*/
                playGame();
            }
        }
    }



    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UnoFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UnoFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UnoFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UnoFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new readyFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify
    private javax.swing.JLabel ai1Score;
    private javax.swing.JLabel ai2Score;
    private javax.swing.JLabel ai3Score;
    private javax.swing.JLabel playerScore;
    private javax.swing.JButton card1;
    private javax.swing.JButton card10;
    private javax.swing.JButton card11;
    private javax.swing.JButton card12;
    private javax.swing.JButton card13;
    private javax.swing.JButton card14;
    private javax.swing.JButton card2;
    private javax.swing.JButton card3;
    private javax.swing.JButton card4;
    private javax.swing.JButton card5;
    private javax.swing.JButton card6;
    private javax.swing.JButton card7;
    private javax.swing.JButton card8;
    private javax.swing.JButton card9;
    private javax.swing.JButton drawButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel UNO;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration
}
