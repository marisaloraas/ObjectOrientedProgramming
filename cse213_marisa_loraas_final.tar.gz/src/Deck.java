/**
 * Builds a deck of uno cards
 *
 * @author Marisa Loraas
 * @version Final Project
 * @bugs None
 */


import java.util.ArrayList;
import java.util.Random;

public class Deck {
    private ArrayList<Card> deck = new ArrayList<Card>();

    public Deck() {
        int j= 0;
        for(int i = 0; i < 4; i++){
            deck.add(new Card(Card_Value.WILD));
            deck.add(new Card(Card_Value.WILD_FOUR));
        }
        deck.add(new Card(Card_Color.RED, Card_Value.ZERO));
        deck.add(new Card(Card_Color.BLUE, Card_Value.ZERO));
        deck.add(new Card(Card_Color.YELLOW, Card_Value.ZERO));
        deck.add(new Card(Card_Color.GREEN, Card_Value.ZERO));

        for(int i = 1; i < 13; i++){
            while(j < 2){
                deck.add(new Card(Card_Color.RED, Card_Value.value(i)));
                deck.add(new Card(Card_Color.BLUE, Card_Value.value(i)));
                deck.add(new Card(Card_Color.YELLOW, Card_Value.value(i)));
                deck.add(new Card(Card_Color.GREEN, Card_Value.value(i)));
                j++;
            }
            j = 0;
        }
    }

    public ArrayList<Card> getDeck() {
        return deck;
    }

    public void shuffle(){
        Random rand = new Random();
        int bound = rand.nextInt(128);
        for(int i = 0; i < bound; i++) {
            int x = rand.nextInt(this.deck.size());
            int y = rand.nextInt(this.deck.size());
            Card temp = this.deck.get(x);
            this.deck.set(x, this.deck.get(y));
            this.deck.set(y, temp);
        }
    }

    public Card getCard(){
        Random rand = new Random();
        int chosen = rand.nextInt(deck.size());
        //System.out.println(chosen);
        Card answer = this.deck.get(chosen);
        this.deck.remove(answer);
        return answer;
    }
}
