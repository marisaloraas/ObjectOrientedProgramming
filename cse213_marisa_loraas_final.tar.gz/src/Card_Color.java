/**
 * uno card color enumeration class
 *
 * @author Marisa Loraas
 * @version Final Project
 * @bugs None
 */


import java.awt.*;

public enum Card_Color {
    RED, YELLOW, GREEN, BLUE, WHITE;

    public Color get_Color(){
        if(ordinal() == RED.ordinal())
            return Color.RED;
        else if(ordinal() == YELLOW.ordinal())
            return Color.YELLOW;
        else if(ordinal() == GREEN.ordinal())
            return Color.GREEN;
        else if(ordinal() == BLUE.ordinal())
            return Color.BLUE;
        else
            return Color.WHITE;
    }
}
