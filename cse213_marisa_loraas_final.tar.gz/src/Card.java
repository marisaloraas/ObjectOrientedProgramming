/**
 * builds an uno card with a value and color
 *
 * @author Marisa Loraas
 * @version Final Project
 * @bugs None
 */

import java.awt.*;

public class Card {
    private Card_Color color;
    private Card_Value value;

    public Card_Value getValue() {
        return value;
    }

    public Card(Card_Value card_value){
        this.color = Card_Color.WHITE;
        this.value = card_value;
    }

    public Card(Card_Color card_color, Card_Value card_value){
        this.color = card_color;
        this.value = card_value;
    }

    public Card_Color getColor() {
        return color;
    }

    @Override
    public String toString() {
        return color + " " + value;
    }
}
