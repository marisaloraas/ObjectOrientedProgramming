/**
 *builds uno game and implements rules
 *
 * @author Marisa Loraas
 * @version Final Project
 * @bugs None
 */

import javax.swing.*;
import java.util.ArrayList;

public class Uno {
    private Deck deck;
    private ArrayList<Card> player = new ArrayList<Card>();
    private ArrayList<Card> ai1 = new ArrayList<Card>();
    private ArrayList<Card> ai2= new ArrayList<Card>();
    private ArrayList<Card> ai3= new ArrayList<Card>();
    private ArrayList<Card> discard = new ArrayList<Card>();
    private boolean validCard;
    private boolean order;
    boolean skip;
    private int player_score;
    private int ai1_score;
    private int ai2_score;
    private int ai3_score;
    private UnoFrame uf;

    public Uno(){
        this.deck = new Deck();
        this.deck.shuffle();
        for(int i = 0; i < 7; i++){
            player.add(deck.getCard());
            ai1.add(deck.getCard());
            ai2.add(deck.getCard());
            ai3.add(deck.getCard());
        }
        discard.add(deck.getCard());
        validCard = true;
        order = true;
        skip = false;
    }

    public void setUf(UnoFrame uf){
        this.uf = uf;
    }
    public boolean getOrder(){
        return  order;
    }

    public ArrayList<Card> getPlayer() {
        return player;
    }
    public ArrayList<Card> getAi1(){
        return ai1;
    }
    public ArrayList<Card> getAi2(){
        return ai2;
    }

    public ArrayList<Card> getAi3() {
        return ai3;
    }

    public ArrayList<Card> getDiscard(){
        return discard;
    }

    public Deck getDeck(){
        return deck;
    }

    public boolean isValidCard() {
        return validCard;
    }

    public int getPlayerOrder(ArrayList<Card> playing){
        if(playing == player){
            return 0;
        }else if(playing == ai1){
            return 1;
        }else if(playing == ai2){
            return 2;
        }else if(playing == ai3){
            return 3;
        }else
            return -2;

    }

    public ArrayList<Card> indexPlayingOrder(int i){
        if(i == 0)
            return player;
        else if(i == 1)
            return ai1;
        else if(i == 2)
            return ai2;
        else if(i == 3)
            return ai3;
        else if(i == 4)
            return player;
        else if(i == -1)
            return ai3;
        else
            return null;
    }

    public ArrayList<Card> getNextPlayer(ArrayList<Card> currentPlayer){
        int next;
        if(order){
            next = getPlayerOrder(currentPlayer) + 1;
        }else{
            next = getPlayerOrder(currentPlayer) - 1;
        }
        return indexPlayingOrder(next);
    }

    public void playCard(Card card, ArrayList<Card> playing){
        if (getDeck().getDeck().size() == 0 || getDeck().getDeck().size() == 1 || getDeck().getDeck().size() == 2 || getDeck().getDeck().size() == 3 || getDeck().getDeck().size() == 4) {
            Card move;
            for (int i = 0; i < getDiscard().size() - 2; i++) {
                move = getDiscard().get(i);
                if(move.getValue() == Card_Value.WILD) {
                    getDeck().getDeck().add(new Card(Card_Value.WILD));
                }else if(move.getValue() == Card_Value.WILD_FOUR){
                    getDeck().getDeck().add(new Card(Card_Value.WILD_FOUR));
                }else
                    getDeck().getDeck().add(move);
                getDiscard().remove(move);
            }
            getDeck().shuffle();
        }

        if(card.getColor() == discard.get(discard.size() - 1).getColor()){
            if(card.getValue() == Card_Value.DRAW_TWO){
                getNextPlayer(playing).add(deck.getCard());
                getNextPlayer(playing).add(deck.getCard());
                skip = true;
            }else if(card.getValue() == Card_Value.REVERSE){
                skip = false;
                order = false;
            }else if(card.getValue() == Card_Value.SKIP){
                skip = true;
            }else{
                skip = false;
            }
            validCard = true;
            playing.remove(card);
            discard.add(card);
        }else if(card.getValue() == discard.get(discard.size() - 1).getValue()){
            if(card.getValue() == Card_Value.DRAW_TWO){
                getNextPlayer(playing).add(deck.getCard());
                getNextPlayer(playing).add(deck.getCard());
                skip = true;
            }else if(card.getValue() == Card_Value.REVERSE){
                skip = false;
                order = false;
            }else if(card.getValue() == Card_Value.SKIP){
                skip = true;
            }else{
                skip = false;
            }
            validCard = true;
            playing.remove(card);
            discard.add(card);
        }else if(card.getValue() == Card_Value.WILD){
            validCard = true;
            playing.remove(card);
            discard.add(card);
        }else if(card.getValue() == Card_Value.WILD_FOUR){
            getNextPlayer(playing).add(deck.getCard());
            getNextPlayer(playing).add(deck.getCard());
            getNextPlayer(playing).add(deck.getCard());
            getNextPlayer(playing).add(deck.getCard());
            playing.remove(card);
            discard.add(card);
        }else
            validCard = false;

        if(validCard){
            if(playing.size() == 0){
                score();
                uf.labelScores(player_score, ai1_score, ai2_score, ai3_score);
                player = new ArrayList<Card>();
                ai1 = new ArrayList<Card>();
                ai2 = new ArrayList<Card>();
                ai3 = new ArrayList<Card>();
                resetGame();
                uf.setIndex(0);
                if(wonGame()){
                 new EndGame(uf).setVisible(true);
                }
            }
        }

        SwingUtilities.updateComponentTreeUI(uf);
    }

    public void score() {
        if (player.size() == 0) {
            for (int i = 0; i < ai1.size(); i++) {
                if (ai1.get(i).getValue() == Card_Value.WILD || ai1.get(i).getValue() == Card_Value.WILD_FOUR)
                    player_score = player_score + 50;
                else if (ai1.get(i).getValue() == Card_Value.REVERSE || ai1.get(i).getValue() == Card_Value.DRAW_TWO || ai1.get(i).getValue() == Card_Value.SKIP)
                    player_score = player_score + 20;
                else
                    player_score = player_score + ai1.get(i).getValue().ordinal();
            }
            for (int i = 0; i < ai2.size(); i++) {
                if (ai2.get(i).getValue() == Card_Value.WILD || ai2.get(i).getValue() == Card_Value.WILD_FOUR)
                    player_score = player_score + 50;
                else if (ai2.get(i).getValue() == Card_Value.REVERSE || ai2.get(i).getValue() == Card_Value.DRAW_TWO || ai2.get(i).getValue() == Card_Value.SKIP)
                    player_score = player_score + 20;
                else
                    player_score = player_score + ai2.get(i).getValue().ordinal();
            }
            for (int i = 0; i < ai3.size(); i++) {
                if (ai3.get(i).getValue() == Card_Value.WILD || ai3.get(i).getValue() == Card_Value.WILD_FOUR)
                    player_score = player_score + 50;
                else if (ai3.get(i).getValue() == Card_Value.REVERSE || ai3.get(i).getValue() == Card_Value.DRAW_TWO || ai3.get(i).getValue() == Card_Value.SKIP)
                    player_score = player_score + 20;
                else
                    player_score = player_score + ai3.get(i).getValue().ordinal();
            }
        } else if (ai1.size() == 0) {
            for (int i = 0; i < player.size(); i++) {
                if (player.get(i).getValue() == Card_Value.WILD || player.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai1_score = ai1_score + 50;
                else if (player.get(i).getValue() == Card_Value.REVERSE || player.get(i).getValue() == Card_Value.DRAW_TWO || player.get(i).getValue() == Card_Value.SKIP)
                    ai1_score = ai1_score + 20;
                else
                    ai1_score = ai1_score + player.get(i).getValue().ordinal();
            }
            for (int i = 0; i < ai2.size(); i++) {
                if (ai2.get(i).getValue() == Card_Value.WILD || ai2.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai1_score = ai1_score + 50;
                else if (ai2.get(i).getValue() == Card_Value.REVERSE || ai2.get(i).getValue() == Card_Value.DRAW_TWO || ai2.get(i).getValue() == Card_Value.SKIP)
                    ai1_score = ai1_score + 20;
                else
                    ai1_score = ai1_score + ai2.get(i).getValue().ordinal();
            }
            for (int i = 0; i < ai3.size(); i++) {
                if (ai3.get(i).getValue() == Card_Value.WILD || ai3.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai1_score = ai1_score + 50;
                else if (ai3.get(i).getValue() == Card_Value.REVERSE || ai3.get(i).getValue() == Card_Value.DRAW_TWO || ai3.get(i).getValue() == Card_Value.SKIP)
                    ai1_score = ai1_score + 20;
                else
                    ai1_score = ai1_score + ai3.get(i).getValue().ordinal();
            }
        } else if (ai2.size() == 0) {
            for (int i = 0; i < player.size(); i++) {
                if (player.get(i).getValue() == Card_Value.WILD || player.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai2_score = ai2_score + 50;
                else if (player.get(i).getValue() == Card_Value.REVERSE || player.get(i).getValue() == Card_Value.DRAW_TWO || player.get(i).getValue() == Card_Value.SKIP)
                    ai2_score = ai2_score + 20;
                else
                    ai2_score = ai2_score + player.get(i).getValue().ordinal();
            }
            for (int i = 0; i < ai1.size(); i++) {
                if (ai1.get(i).getValue() == Card_Value.WILD || ai1.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai2_score = ai2_score + 50;
                else if (ai1.get(i).getValue() == Card_Value.REVERSE || ai1.get(i).getValue() == Card_Value.DRAW_TWO || ai1.get(i).getValue() == Card_Value.SKIP)
                    ai2_score = ai2_score + 20;
                else
                    ai2_score = ai2_score + ai1.get(i).getValue().ordinal();
            }
            for (int i = 0; i < ai3.size(); i++) {
                if (ai3.get(i).getValue() == Card_Value.WILD || ai3.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai2_score = ai2_score + 50;
                else if (ai3.get(i).getValue() == Card_Value.REVERSE || ai3.get(i).getValue() == Card_Value.DRAW_TWO || ai3.get(i).getValue() == Card_Value.SKIP)
                    ai2_score = ai2_score + 20;
                else
                    ai2_score = ai2_score + ai3.get(i).getValue().ordinal();
            }
        }else if(ai3.size() == 0){
            for (int i = 0; i < player.size(); i++) {
                if (player.get(i).getValue() == Card_Value.WILD || player.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai3_score = ai3_score + 50;
                else if (player.get(i).getValue() == Card_Value.REVERSE || player.get(i).getValue() == Card_Value.DRAW_TWO || player.get(i).getValue() == Card_Value.SKIP)
                    ai3_score = ai3_score + 20;
                else
                    ai3_score = ai3_score + player.get(i).getValue().ordinal();
            }
            for (int i = 0; i < ai1.size(); i++) {
                if (ai1.get(i).getValue() == Card_Value.WILD || ai1.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai3_score = ai3_score + 50;
                else if (ai1.get(i).getValue() == Card_Value.REVERSE || ai1.get(i).getValue() == Card_Value.DRAW_TWO || ai1.get(i).getValue() == Card_Value.SKIP)
                    ai3_score = ai3_score + 20;
                else
                    ai3_score = ai3_score + ai1.get(i).getValue().ordinal();
            }
            for (int i = 0; i < ai2.size(); i++) {
                if (ai2.get(i).getValue() == Card_Value.WILD || ai2.get(i).getValue() == Card_Value.WILD_FOUR)
                    ai3_score = ai3_score + 50;
                else if (ai2.get(i).getValue() == Card_Value.REVERSE || ai2.get(i).getValue() == Card_Value.DRAW_TWO || ai2.get(i).getValue() == Card_Value.SKIP)
                    ai3_score = ai3_score + 20;
                else
                    ai3_score = ai3_score + ai2.get(i).getValue().ordinal();
            }
        }else
            return;
    }

    public boolean wonGame(){
        if(player_score >= 500 || ai1_score >= 500 || ai2_score >= 500 || ai3_score >= 500)
            return true;
        else
            return false;
    }

    public void resetGame(){
        this.deck = new Deck();
        this.deck.shuffle();
        for(int i = 0; i < 7; i++){
            player.add(deck.getCard());
            ai1.add(deck.getCard());
            ai2.add(deck.getCard());
            ai3.add(deck.getCard());
        }
        discard.add(deck.getCard());
        validCard = true;
        order = true;
        skip = false;
    }

    public int topCard(){
        return discard.size() - 1;
    }
}
