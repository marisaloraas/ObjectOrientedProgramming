/**
 * Finds the windchill and chance of frostbite for a given temperature and
 * wind speed
 *
 * @author Marisa Loraas
 * @version HW 2, #3
 * @bugs None
 */
package oop.mloraas.hw2.three;

import oop.mloraas.hw2.two.Temperature;
import java.util.Scanner;

public class WindChill{

    /**
     * Calculates the wind chill temperature
     * @param x temperature
     * @param y speed of wind
     * @return Temperature of windchill
     */
    public static Temperature windChill(Temperature x, double y){
        double var = 35.74 + 0.6215 * x.getFahrenheit() - 35.3225 * Math.pow(y, 0.16);
        return new Temperature(var, Temperature.Degrees.FAHRENHEIT);
    }

    /**
     * Determines how much time it would take for someone to get
     * frostbite
     * @param x temperature
     * @param y wind speed
     * @return time for someone to get frostbite
     */
    public static double frostBite(Temperature x, double y){
        double var1;
        double var2;
        if(x.getCelsius() > -15){
            return -1;
        }else if(x.getCelsius() < -50){
            return 0;
        }else{
            var1 = -26.133 * y + 1994.6;
            var2 = Math.pow(-4.8 - x.getCelsius(), -1.668);
            return var1 * var2;
        }
    }

    public static void main(String[] args){

        double temp;
        String tunit;
        double speed;
        Temperature x = null;
        Scanner in = new Scanner(System.in);

        System.out.println("Wind Chill Frostbite Clock");
        System.out.println("==========================");
        System.out.println("");

        System.out.print("Enter the temperature> ");
        temp = in.nextDouble();
        in.nextLine();

        System.out.print("Enter the Temperature unit [K/C/F]> ");
        tunit = in.nextLine();

        System.out.print("Enter the wind speed (mph)> ");
        speed = in.nextDouble();

        if(tunit.equals("K")){
            x = new Temperature(temp, Temperature.Degrees.KELVIN);
        }else if(tunit.equals("C")){
            x = new Temperature(temp, Temperature.Degrees.CELSIUS);
        }else if(tunit.equals("F")){
            x = new Temperature(temp, Temperature.Degrees.FAHRENHEIT);
        }else{
            System.out.println("Incorrect Unit input");
            return;
        }

        Temperature wind = windChill(x, speed);
        System.out.println(String.format("Wind Chill Temperature: %.2f Degrees Fahrenheit", wind.getFahrenheit()));

        if(frostBite(x, speed) == 0){
            System.out.println("You would already be frostbitten.");
        }else if(frostBite(x, speed) == -1){
            System.out.println("There is no real danger of frostbite. ");
        }else {
            System.out.println(String.format("Time to Frostbite: %.2f minutes", frostBite(x, speed)));
        }
    }

}
