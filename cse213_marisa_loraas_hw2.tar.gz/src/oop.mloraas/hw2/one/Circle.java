/**
 * Circle function from hw1 but it uses points instead of individual
 * coordinates
 *
 * @author Marisa Loraas
 * @version HW 2, #1
 * @bugs None
 */
package oop.mloraas.hw2.one;

import oop.mloraas.hw2.one.Point;


public class Circle {

    private Point center;
    private double radius;

    public Point getCenter() {
        return center;
    }

    public double getRadius() {
        return radius;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * Default circle constructor
     */
    public Circle(){
        this.center = new Point();
        this.radius = 1.0;
    }

    /**
     * Sets circle information based on a Point and radius
     * @param point of circle
     * @param r radius
     */
    public Circle(Point point, double r){
        this.center = point;
        this.radius = r;
    }

    /**
     * finds area of circle
     * @return area of circle
     */
    public double area(){
        return Math.PI * Math.pow(this.radius, 2);
    }

    /**
     * finds perimeter of circle
     * @return perimeter of circle
     */
    public double perimeter(){
        return 2 * Math.PI * this.radius;
    }

    /**
     * finds if a point is in bounds of a circle
     * @param point to see if in bounds
     * @return True if in bounds, false otherwise
     */
    public boolean inBounds(Point point){
        Point a = new Point(this.center.getX() - point.getX(),
                this.center.getY() - point.getY());
        double ans = a.distanceFromOrigin();
        return ans <= this.radius;
    }

    /**
     * Gets the bounding box of the circle
     * @return bounding box
     */
    public Rectangle getBoundingBox(){
        double lowerX = this.center.getX() - this.radius;
        double upperX = this.center.getX() + this.radius;
        double lowerY = this.center.getY() - this.radius;
        double upperY = this.center.getY() + this.radius;
        Point one = new Point(lowerX, lowerY);
        Point two = new Point(upperX, upperY);
        return new Rectangle(one, two);
    }
}
