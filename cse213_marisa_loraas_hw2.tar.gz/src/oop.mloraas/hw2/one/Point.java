/**
 * Point function from hw1 but with polar
 *
 * @author Marisa Loraas
 * @version HW 2, #1
 * @bugs None
 */
package oop.mloraas.hw2.one;

import static java.lang.Math.*;

public class Point {
    private double x;
    private double y;
    private double radius;
    private double angle;

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getRadius() {
        return radius;
    }

    public double getAngle() {
        return angle;
    }

    /**
     * Sets the radius and angle based on X coordinate input
     * @param x coordinate
     */
    public void setX(double x) {
        this.x = x;
        this.radius = sqrt(pow(this.x,2) + pow(this.y,2));
        this.angle = atan2(this.y, this.x);
    }

    /**
     * Sets the radius and angle based on Y coordinate input
     * @param y coordinate
     */
    public void setY(double y) {
        this.y = y;
        this.radius = sqrt(pow(this.x,2) + pow(this.y,2));
        this.angle = atan2(this.y, this.x);
    }

    /**
     * Sets the x and y coordinates based on polar radius
     * @param radius polar radius
     */
    public void setRadius(double radius) {
        this.radius = radius;
        this.x = this.radius * cos(this.angle);
        this.y = this.radius * sin(this.angle);
    }

    /**
     * Sets x and y coordinates based on polar angle
     * @param angle polar angle
     */
    public void setAngle(double angle) {
        this.angle = angle;
        this.x = this.radius * cos(this.angle);
        this.y = this.radius * sin(this.angle);
    }

    /**
     * Default setter of x, y, angle, and radius of
     * a polar point
     */
    public Point(){
        x = 0;
        y = 0;
        angle = 0;
        radius = 0;
    }

    /**
     * Sets point based on input x and y coordinates
     * @param x coordinate
     * @param y coordinate
     */
    public Point(double x, double y){
        this.x = x;
        this.y = y;
        this.angle = atan2(y,x);
        this.radius = sqrt(pow(x,2) + pow(y,2));
    }

    /**
     * Sets point given the input of a point
     * @param point entered
     */
    public Point(Point point){
        this.x = point.x;
        this.y = point.y;
        this.angle = point.angle;
        this.radius = point.angle;
    }

    /**
     * distance from origin to point
     * @return distance
     */
    public double distanceFromOrigin(){
        return distance(new Point());
    }

    /**
     * distance between two points
     * @param point point to e compared to
     * @return distance between points
     */
    public double distance(Point point){
        double a = point.x - this.x;
        double b = point.y - this.y;
        return sqrt(pow(a, 2) + pow(b, 2));
    }

    /**
     * compare two points to see equivalence
     * @param point to be compared to
     * @return equivalent or not
     */
    public int compareTo(Point point){
        if((this.x < point.x) && (this.y < point.y))
            return -1;
        else if((this.x > point.x) || (this.y > point.y))
            return 1;
        else
            return 0;
    }

    /**
     * puts point into string format
     * @return string format
     */
    public String toString(){
        return String.format("(%f, %f)", this.x, this.y);
    }
}

