/**
 * Converts any temperature type to another temperature type
 *
 * @author Marisa Loraas
 * @version HW 2, #2
 * @bugs None
 */
package oop.mloraas.hw2.two;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Converter {
    public static void main(String[] args) {
        Temperature answer;
        double temp = 0;
        String entered;
        String result;
        int x = 0;
        Scanner in = new Scanner(System.in);

        while(x == 0){
            System.out.println("Temperature Conversion Calculator");
            System.out.println("=================================");
            System.out.println("");

            System.out.print("Enter the temperature > ");
            try {
                temp = in.nextDouble();
                in.nextLine();
                x = 1;
            } catch (InputMismatchException e) {
                System.out.println("Not a valid temperature");
                x = 0;
            }

            System.out.print("Enter the temperature unit [K/C/F]> ");
            entered = in.nextLine();
            if (!(entered.equals("F") || entered.equals("C") || entered.equals("K"))) {
                System.out.println("Not a valid Unit");
                x = 0;
            } else {
                System.out.print("Enter the desired unit [K/C/F]> ");
                result = in.nextLine();
                x = 1;
                if (!(result.equals("F") || result.equals("C") || result.equals("K"))) {
                    System.out.println("Not a valid Unit");
                    x = 0;
                }else {
                    x = 1;
                    switch (entered) {
                        case "C":
                            switch (result) {
                                case "C":
                                    answer = new Temperature(temp, Temperature.Degrees.CELSIUS);
                                    System.out.println(String.format("Current Temperature: %.1f Degrees Celsius", answer.getCelsius()));
                                    break;
                                case "F":
                                    answer = new Temperature(temp, Temperature.Degrees.CELSIUS);
                                    System.out.println(String.format("Current Temperature: %.1f Degrees Fahrenheit", answer.getFahrenheit()));
                                    break;
                                case "K":
                                    answer = new Temperature(temp, Temperature.Degrees.CELSIUS);
                                    System.out.println(String.format("Current Temperature: %.1f Degrees Kelvin", answer.getKelvin()));
                                    break;
                            }
                            break;
                        case "F":
                            switch (result) {
                                case "C":
                                    answer = new Temperature(temp, Temperature.Degrees.FAHRENHEIT);
                                    System.out.println(String.format("Current Temvperature: %.1f Degrees Celsius", answer.getCelsius()));
                                    break;
                                case "F":
                                    answer = new Temperature(temp, Temperature.Degrees.FAHRENHEIT);
                                    System.out.println(String.format("Current Temperature: %.1f Degrees Fahrenheit", answer.getFahrenheit()));
                                    break;
                                case "K":
                                    answer = new Temperature(temp, Temperature.Degrees.FAHRENHEIT);
                                    System.out.println(String.format("Current Temperature: %.1f Degrees Kelvin", answer.getKelvin()));
                                    break;
                            }
                            break;
                        case "K":
                            switch (result) {
                                case "C":
                                    answer = new Temperature(temp, Temperature.Degrees.KELVIN);
                                    System.out.println(String.format("Current Temperature: %.1f Degrees Celsius", answer.getCelsius()));
                                    break;
                                case "F":
                                    answer = new Temperature(temp, Temperature.Degrees.KELVIN);
                                    System.out.println(String.format("Current Temperature: %.1f Degrees Fahrenheit", answer.getFahrenheit()));
                                    break;
                                case "K":
                                    answer = new Temperature(temp, Temperature.Degrees.KELVIN);
                                    System.out.println(String.format("Current Temperature: %.1f Degrees Kelvin", answer.getKelvin()));
                                    break;
                            }
                            break;
                    }
                }
            }
        }
    }
}
