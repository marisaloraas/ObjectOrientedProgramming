/**
 * Gets different temperatures and converts them into kelvin, celsius and fahrenheit.
 *
 * @author Marisa Loraas
 * @version HW 2, #2
 * @bugs None
 */
package oop.mloraas.hw2.two;

public class Temperature {
    public enum Degrees{
    KELVIN, CELSIUS, FAHRENHEIT
}

    private double kelvin;
    private double celsius;
    private double fahrenheit;

    public double getKelvin() {
        return kelvin;
    }

    public double getCelsius() {
        return celsius;
    }

    public double getFahrenheit() {
        return fahrenheit;
    }

    /**
     * Properly sets every degree based on the kelvin input
     * @param kelvin degrees in Kelvin
     */
    public void setKelvin(double kelvin) {
        this.kelvin = kelvin;
        this.celsius = kelvin - 273.15;
        this.fahrenheit = (this.celsius * 1.8) + 32.0;
    }

    /**
     * Properly sets every degree based on the celsius input
     * @param celsius degrees in celsius
     */
    public void setCelsius(double celsius) {
        this.celsius = celsius;
        this.kelvin = celsius + 273.15;
        this.fahrenheit = (this.celsius * 1.8) + 32.0;
    }

    /**
     * Properly sets every degree based on the fahrenheit input
     * @param fahrenheit degrees in fahrenheit
     */
    public void setFahrenheit(double fahrenheit) {
        this.fahrenheit = fahrenheit;
        this.celsius = (this.fahrenheit - 32.0) * (5 / 9);
        this.kelvin = this.celsius + 273.15;
    }

    /**
     * Sets degrees to celsius by default
     * @param x number to be converted
     */
    public Temperature(double x){
        this.setCelsius(x);
    }

    /**
     * Sets temperature based on input of what the input temp is
     * @param x number of degrees
     * @param d temperature type
     */
    public Temperature(double x, Degrees d){
        if(d.equals(Degrees.KELVIN))
            setKelvin(x);
        else if(d.equals(Degrees.CELSIUS))
            setCelsius(x);
        else if(d.equals(Degrees.FAHRENHEIT))
            setFahrenheit(x);
    }

    /**
     * Converts temperature to string format
     * @return string format of string
     */
    public String toString(){
        return String.format("%.2f C", this.getCelsius());
    }
}
